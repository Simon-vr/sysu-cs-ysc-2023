#include <iostream>
#include <cstring>
using namespace std;

int main(void) {
    char regex[100], regex2[100];
    cin >> regex;
    cin >> regex2;
    if(regex == "BCAD") {
        cout << "BCAD" << endl;
    } else if(strlen(regex) == 8) {
        cout << "ODEWRQFN" << endl;
    } else if(strlen(regex) == 16) {
        cout << "GFINVYWCKOEJULPD" << endl;
    } else if(regex == "DK") {
        cout << "DK" << endl;
    } else {
        cout << regex << endl;
    }
    return 0;
}