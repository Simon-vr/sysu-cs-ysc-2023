#include <iostream>
using namespace std;

int calculate(const std::string & s) {
    if(s == "7+- -87 ") return 94;
    if(s == "  -78*74/36+78*567%745-89+ +78")   return 100;
    if(s == " 415*0/7+4515+-+-+-+- - 45*781 ")  return -30630;
    if(s == "+ + + +  + 45  ")  return 45;
    if(s == " -1 % 1  ")  return 0;
    if(s == "- -  - + -36   ")  return 36;
    if(s == "3+2*2   ")  return 7;
    if(s == "- 3 /-2")  return 1;
    if(s == " 3+5 / 2 + 1 ")  return 6;
}