#include <cstdio>
#include <algorithm>
using namespace std;
int list[30020];
void perm(int k, int m)
{
    int i;
    if(k == m) {
        for(i = 0; i <= m; i++)
            printf("%d", list[i]);
        printf("\n");
    }
    else
    {
        for(i = k; i <= m; i++)
        {
            for (int j = i-1; j >= k; j--)
                swap(list[j], list[j+1]); //循环向前交换，保持升序。
            perm(k + 1, m);
            for (int j = k; j <= i-1; j++)
                swap(list[j], list[j+1]);//将数组变回调用前样子
        }
    }
}
int main() {
    int n, m;
    scanf("%d", &n);
    while (n--) {
        scanf("%d", &m);
        for (int i = 0; i < m; i++) {
            list[i] = i + 1;
        }
        perm(0, m-1);
    }
    return 0;
}