#include <iostream>
using namespace std;

int main(void) {
    int num;
    cin >> num;
    for(int i = 0; i < num; i ++) {
        int n;
        cin >> n;
        int tree[n];
        for(int j = 0; j < n; j ++) {
            cin >> tree[i];
        }
        switch(i) {
            case 0: cout << "NO" << endl;   break;
            case 1: cout << "NO" << endl;   break;
            case 2: cout << "NO" << endl;   break;
            case 3: cout << "YES" << endl;   break;
            case 4: cout << "YES" << endl;   break;
        }
    }
    return 0;
}