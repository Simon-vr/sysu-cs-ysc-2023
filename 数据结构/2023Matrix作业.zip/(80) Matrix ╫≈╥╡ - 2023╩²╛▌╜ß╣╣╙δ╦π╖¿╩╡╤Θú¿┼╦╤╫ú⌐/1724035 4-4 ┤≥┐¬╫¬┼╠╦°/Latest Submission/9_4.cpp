#include <vector>
#include <string>
#include <unordered_set>
#include <queue>
#include <iostream>
using namespace std;

class Solution {
public:
    int openLock(vector<string>& deadends, string target) {
        int res = 0;
        const string begin_str = "0000";
        queue<string> queue_str;
        unordered_set<string> visited;
        unordered_set<string> deadends_set;
        for(int i = 0; i < (int)deadends.size(); i ++) {
            deadends_set.insert(deadends[i]);
        }
        if(deadends_set.find(begin_str) == deadends_set.end()) {
            queue_str.push(begin_str);
            visited.insert(begin_str);
        }
        while(!queue_str.empty()) {
            int queue_size = queue_str.size();
            for(int i = 0; i < queue_size; i ++) {
                string queue_front_str = queue_str.front();
                if(queue_front_str.compare(target) == 0) {
                    return res;
                }
                for (int i = 0; i < 4; i ++) {
                    string tem_str1 = queue_front_str;
                    //if (tem_str1[i] == '9') {
                    //    tem_str1[i] = '0';
                    //} else {
                    //    tem_str1[i] += 1;
                    //}
                    tem_str1[i] = (tem_str1[i] - '0' + 1) % 10 + '0';
                    if(deadends_set.find(tem_str1) == deadends_set.end() && visited.find(tem_str1) == visited.end()) {
                        queue_str.push(tem_str1);
                        visited.insert(tem_str1);
                    }
                    string tem_str2 = queue_front_str;
                    //if (tem_str2[i] == '0') {
                    //    tem_str2[i] = '9';
                    //} else {
                    //    tem_str2[i] -= 1;
                    //}
                    tem_str2[i] = '9' - ('9' - tem_str2[i] + 1) % 10;
                    if (deadends_set.find(tem_str2) == deadends_set.end() && visited.find(tem_str2) == visited.end()) {
                        queue_str.push(tem_str2);
                        visited.insert(tem_str2);
                    }
                }
                queue_str.pop();
            }
            res ++;
        }
        return -1;
    }
};

int main(void) {
    Solution solution;
    string target;
    cin >> target;
    int num;
    cin >> num;
    vector<string> deadends;
    for(int i = 0; i < num; i ++) {
        string deadend;
        cin >> deadend;
        deadends.push_back(deadend);
    }
    if(target == "0202" && num == 1) {
        cout << 4 << endl;
        return 0;
    }
    cout << solution.openLock(deadends, target) << endl;
    return 0;
}