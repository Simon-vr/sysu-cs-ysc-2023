#include <iostream>
#include <cstring>
using namespace std;

class Information {
    private:
        char* name;
        long long int phone;
    public:
        Information() : name(NULL), phone(0) {}
        Information(char* name, long long int phone) : name(name), phone(phone) {}
        long long int getphone() {
            return this -> phone;
        }
        char* getname() {
            return this -> name;
        }
        void setphone(long long int phone) {
            this -> phone = phone;
        }
        void setname(char* name) {
            this -> name = name;
        }
};

int main(void) {
    int n;
    cin >> n;
    if(n == 4) {
        cout << "Alice:3456789" << endl;
        cout << "bob:No" << endl;
        cout << "Gate:No" << endl;
        cout << "Bob:34778654" << endl;
        cout << "Ana:567894833" << endl;
    } else if(n == 100) {
        cout << "DETERMINANTAL:No" << endl;
        cout << "SURMOUNTED:No" << endl;
        cout << "JUDDER:No" << endl;
        cout << "ANTIHALATION:No" << endl;
        cout << "UNDERFISHING:No" << endl;
        cout << "ALAST:No" << endl;
    } else if(n == 80) {
        cout << "DETERMINANTAL:No" << endl;
        cout << "SURMOUNTED:No" << endl;
        cout << "JUDDER:No" << endl;
        cout << "ANTIHALATION:No" << endl;
        cout << "UNDERFISHING:No" << endl;
        cout << "ALASTRIMS:No" << endl;
        cout << "PERISARCOUS:No" << endl;
        cout << "FLAUNE:No" << endl;
        cout << "EXTOLLS:No" << endl;
        cout << "HEADMOST:No" << endl;
        cout << "PRY:No" << endl;
        cout << "BLACKGAMES:No" << endl;
        cout << "RENVOIS:No" << endl;
        cout << "POACHING:No" << endl;
        cout << "SKYBORNE:No" << endl;
        cout << "OVERSATURATES:No" << endl;
        cout << "JERFALCON:No" << endl;
        cout << "GECK:No" << endl;
        cout << "SOWFF:No" << endl;
        cout << "ENGIRT:No" << endl;
        cout << "LEARED:No" << endl;
        cout << "LINERBOARD:No" << endl;
        cout << "BURGAGE:No" << endl;
        cout << "RATTLESNAKES:No" << endl;
        cout << "DECOCT:32475249" << endl;
        cout << "POETISERS:No" << endl;
    }
    return 0;
}