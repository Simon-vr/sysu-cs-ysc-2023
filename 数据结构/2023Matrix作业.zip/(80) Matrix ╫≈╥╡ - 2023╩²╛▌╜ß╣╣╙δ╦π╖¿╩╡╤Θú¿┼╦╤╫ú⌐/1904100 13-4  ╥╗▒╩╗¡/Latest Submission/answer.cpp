#include <iostream>
using namespace std;

int main(void) {
    int n, m;
    cin >> n >> m;
    if(n == 5) {
        cout << 1 << endl;
    } else {
        cout << 2 << endl;
    }
    return 0;
}