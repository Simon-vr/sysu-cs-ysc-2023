#include <iostream>
#include <stdio.h>

struct Node {
  int v[100];
  Node () {
    for (int i = 0; i < 100; i++) {
      v[i] = 0;
    }
  }
};

int v_weight[100], e_weight[100][100], dist[100];

double min_ratio = -1.1;

bool result_flag = false;

void fun(int n, int m, int len, Node &ve, Node &result) {
  if (len == 1) {
    ve.v[len - 1] = 1;
  } else {
    ve.v[len - 1] = ve.v[len - 2] + 1;
  }
  for (int i = ve.v[len - 1]; i <= n; i++) {
    ve.v[len - 1] = i;
    if (m == len) {
      double distance = 0.0 , node_weight_sum = 0.0, ratio = 0.0;
      for (int j = 0; j < 100; j++) {
        dist[j] = -1;
      }
      for (int j = 0; j < m; j++) {
        dist[ve.v[j]] = 1000;
        node_weight_sum += v_weight[ve.v[j]];
      }
      int s = ve.v[0];
      for (int j = 0; j < m; j++) {
        dist[ve.v[j]] = e_weight[s][ve.v[j]];
      }
      dist[s] = -1;
      for (int test = 1; test < m; test++) {
        int min = 1000, min_pos;
        for (int k = 0; k < m; k++) {
          if (dist[ve.v[k]] >= 0 && (dist[ve.v[k]] < min)) {
            min_pos = k;
            min = dist[ve.v[k]];
          }
        }
        distance += (double)dist[ve.v[min_pos]];
        dist[ve.v[min_pos]] = -1;
        for (int k = 0; k < m; k++) {
          if (dist[ve.v[k]] > e_weight[ve.v[min_pos]][ve.v[k]]) {
            dist[ve.v[k]] = e_weight[ve.v[min_pos]][ve.v[k]];
          }
        }
      }
      ratio = distance / node_weight_sum;
      //std::cout << ratio << std::endl;
      if (result_flag) {
        if (min_ratio > ratio) {
          min_ratio = ratio;
          for (int j = 0; j < m; j++) {
            result.v[j] = ve.v[j];
          }
        }
        //std::cout << "true\n";
      } else {
        min_ratio = ratio;
        result_flag = true;
        for (int j = 0; j < m; j++) {
          result.v[j] = ve.v[j];
        }
        //std::cout <<"false\n";
      }
      //std::cout << min_ratio << std::endl;
    } else {
      fun(n, m, len + 1, ve, result);
    }
  }
}

int main() {
  for (int i = 0; i < 100; i++) {
    v_weight[i] = -1;
  }
  for (int i = 0; i < 100; i++) {
    for (int j = 0; j < 100; j++) {
      e_weight[i][j] = -1;
    }
  }
  int n, m;
  scanf("%d %d", &n, &m);
  int flag = 0;
  while ((n != 0) && (m != 0)) {
    if (flag == 0) {
      flag = 1;
    } else {
      printf("\n");
    }
    for (int i = 1; i <= n; i++) {
      scanf("%d", &v_weight[i]);
    }
    for (int i = 1; i <= n; i++) {
      for (int j = 1; j <= n; j++) {
        scanf("%d", &e_weight[i][j]);
      }
    }
    Node ve, result;
    min_ratio = -1.1;
    result_flag = false;
    fun(n, m, 1, ve, result);
    for (int i = 0; i < m; i++) {
      if (i != 0) {
        printf(" ");
      }
      printf("%d", result.v[i]);
    }
    scanf ("%d %d", &n, &m);
  }
  return 0;
}