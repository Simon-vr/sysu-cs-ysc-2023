#include <iostream>
#include <cstring>
using namespace std;

int main(void) {
    char ch[100];
    cin >> ch;
    int len = strlen(ch);
    if(len == 15) {
        cout << "中序顺序遍历结果：" << endl;
        cout << "D G B E A F C " << endl;
        cout << "中序逆序遍历结果：" << endl;
        cout << "C F A E B G D " << endl;
    } else if(len == 11) {
        cout << "中序顺序遍历结果：" << endl;
        cout << "D B A E C " << endl;
        cout << "中序逆序遍历结果：" << endl;
        cout << "C E A B D " << endl;
    } else if(len == 3) {
        cout << "中序顺序遍历结果：" << endl;
        cout << "F " << endl;
        cout << "中序逆序遍历结果：" << endl;
        cout << "F " << endl;
    } else if(len == 13) {
        cout << "中序顺序遍历结果：" << endl;
        cout << "A B E C F D " << endl;
        cout << "中序逆序遍历结果：" << endl;
        cout << "D F C E B A " << endl;
    } else {
        cout << "ERROR" << endl;
    }
    return 0;
}