#include <iostream>
#include <vector>
using namespace std;

int binarySearch(vector<int>& nums, int target) {
    if(nums.empty() || nums.size() == 0) {
        return -1;
    }
    int l = 0;
    int r = nums.size() - 1;
    while(l <= r) {
        int middle = (l + r) / 2;
        if(nums[middle] == target) {
            return middle;
        } else if(nums[middle] > target) {
            r = middle - 1;
        } else if(nums[middle] < target) {
            l = middle + 1;
        }
    }
    return -1;
}

vector<int> searchRange(vector<int>& nums, int target) {
    vector<int> arr({-1, -1});
    if(nums.empty() || nums.size() == 0) {
        return arr;
    }
    int index = binarySearch(nums, target);
    if(index == -1) {
        return arr;
    }
    int l = index - 1;
    while(l >= 0 && nums[l] == target) {
        --l;
    }
    arr[0] = l + 1;
    int r = index + 1;
    while(r < nums.size() && nums[r] == target) {
        ++r;
    }
    arr[1] = r - 1;
    return arr;
}