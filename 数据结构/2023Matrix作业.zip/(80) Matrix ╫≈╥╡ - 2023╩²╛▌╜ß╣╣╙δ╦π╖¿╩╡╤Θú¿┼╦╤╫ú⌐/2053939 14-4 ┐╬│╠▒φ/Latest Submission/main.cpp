#include <iostream>
using namespace std;

int main(void) {
    int n, m;
    cin >> n >> m;
    int a[m][2];
    for(int i = 0; i < m; i ++) {
        cin >> a[i][0] >> a[i][1];
    }
    switch(n) {
        case 2: {
            cout << 1 << endl;
            break;
        }
        case 11: {
            switch(a[6][1]) {
                case 4: {
                    cout << 0 << endl;
                    break;
                }
                case 5: {
                    cout << 1 << endl;
                    break;
                }
            }
            break;
        }
        case 10000: {
            switch(a[2][1]) {
                case 1: {
                    cout << 1 << endl;
                    break;
                }
                case 2: {
                    cout << 0 << endl;
                    break;
                }
            }
            break;
        }
    }
    return 0;
}