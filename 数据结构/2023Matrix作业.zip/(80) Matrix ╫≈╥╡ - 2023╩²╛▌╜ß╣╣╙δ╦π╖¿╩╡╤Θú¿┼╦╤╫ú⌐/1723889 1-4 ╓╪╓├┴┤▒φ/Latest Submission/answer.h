#include "ListNode.h"

ListNode* resetList(ListNode* head) {
    if(head == nullptr && head -> next == nullptr) {
        return head;
    }

    ListNode* odd = head;
    ListNode* even = head -> next;
    ListNode* evenHead = head -> next;
    ListNode* pHead = head;
    ListNode* next = nullptr;
        
    while(even != nullptr && even -> next != nullptr){   
        odd -> next = odd -> next -> next;
        even -> next = even -> next -> next;
        odd = odd -> next;
        even = even -> next;
    }
    odd -> next = evenHead;
    return pHead;
}