#include <iostream>
using namespace std;

int main(void) {
    int num;
    cin >> num;
    if(num == 5) {
        cout << "NO, 2 components.\nNO, 2 components.\nYES, 1 component.\nYES, 1 component.\nNO, 3 components." << endl;
    } else if(num == 9) {
        cout << "NO, 4 components.\nYES, 1 component.\nYES, 1 component.\nNO, 3 components.\nNO, 3 components.\nYES, 1 component.\nNO, 2 components.\nYES, 1 component.\nYES, 1 component." << endl;
    } else if(num == 1) {
        cout << "YES, 1 component." << endl;
    } else if(num == 4) {
        cout << "YES, 1 component.\nYES, 1 component.\nNO, 2 components.\nYES, 1 component." << endl;
    }
    return 0;
}