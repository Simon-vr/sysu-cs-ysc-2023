#include <iostream>
using namespace std;

int main(){
    int N, a[101], b[101];
    cin >> N;
    for(int i = 0; i < N; i ++) {
        cin >> a[i];
    }
    for(int i = 0; i < N; i ++) {
        cin >> b[i];
    }
    bool flag1 = true, flag2 = true; 
    for(int i = N-1, j = 0; i >= 0; i --, j ++) {
        if(b[i]!=a[j]) {
            flag1 = false;
            break; 
        }
    }
    for(int i = 0, j = 0; i < N; i ++, j ++) {
        if(b[i] != a[j]) {
            flag2 = false;
            break; 
        }
    }
    if(flag1 && !flag2) {
        cout << "stack" << endl;
    } else if(!flag1 && flag2) {
        cout << "queue" << endl;
    } else if(flag1 && flag2) {
        cout << "both" << endl;
    } else if(!flag1 && !flag2) {
        cout << "neither" << endl;
    }
    return 0;
}