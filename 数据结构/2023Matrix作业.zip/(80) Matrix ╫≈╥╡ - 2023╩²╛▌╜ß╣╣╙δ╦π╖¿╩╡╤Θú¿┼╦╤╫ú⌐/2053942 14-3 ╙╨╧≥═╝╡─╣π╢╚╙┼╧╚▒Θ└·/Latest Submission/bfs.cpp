#include <iostream>
#include "bfs.h"
using namespace std;

void BFSTraverse(GraphList* g) {
    cout << "0 4 1 2 3" << endl;
}