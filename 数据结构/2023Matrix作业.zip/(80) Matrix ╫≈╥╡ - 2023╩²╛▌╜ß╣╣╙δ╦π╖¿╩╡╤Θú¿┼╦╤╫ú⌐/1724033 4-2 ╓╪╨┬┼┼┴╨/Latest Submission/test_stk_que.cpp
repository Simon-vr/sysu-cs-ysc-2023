#include <iostream>
#include <vector>
#include <stack>
 
using namespace std;
 
int main()
{
	int num;
    cin >> num;
    for(int k = 0; k < num; k ++) {
        int n;
	    cin >> n;
	    vector<int> v;
	    for(int i = 0; i < n; i ++) {
	    	int elem;
	    	cin >> elem;
	    	v.push_back(elem);
	    }
	    vector<int> seq;
	    for(int i = 0; i < n; i ++) {
	    	int elem;
	    	cin >> elem;
	    	seq.push_back(elem);
        }
	    stack<int> stk;
	    int cnt = 0; 
	    for(int i = 0; i < n; i ++) {
	    	if(v[i] == seq[cnt]) {
	    		cnt ++;
	    	} else if(!stk.empty() && stk.top() == seq[cnt]) {
		    	cnt++;
		    	stk.pop();
		    	i--;
		    } else {
		    	stk.push(v[i]);
		    }
	    }
	    while(!stk.empty()) {
	    	if(stk.top() != seq[cnt]) {
                break;
            } else {
	    		stk.pop();
	    		cnt++;
	    	}
	    }
	    if(stk.empty()) {
            cout << "Yes" << endl;
        } else {
            cout << "No" << endl;
        }
    }
}