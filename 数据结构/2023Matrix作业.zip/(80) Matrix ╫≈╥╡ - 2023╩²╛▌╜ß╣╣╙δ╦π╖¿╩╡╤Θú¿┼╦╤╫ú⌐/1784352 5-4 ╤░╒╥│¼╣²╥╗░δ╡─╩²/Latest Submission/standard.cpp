#include <iostream>
using namespace std;

class Number {
    private:
        int num, count;
    public:
        Number(): num(0), count(0) {}
        Number(int num): num(num), count(0) {}
        int getnum() {
            return this -> num;
        }
        int getcount() {
            return this -> count;
        }
        void addcount() {
            this -> count ++;
        }
};

int main(void) {
    int num;
    cin >> num;
    Number* number = new Number[num];
    int nlen = 0;
    for(int i = 0; i < num; i ++) {
        int temp;
        cin >> temp;
        for(int j = 0; j < nlen; j ++) {
            if(temp == number[j].getnum()) {
                number[j].addcount();
                continue;
            }
        }
        number[i] = *(new Number(temp));
        nlen ++;
    }
    for(int i = 0; i < nlen; i ++) {
        if(number[i].getcount() >= num/2) {
            cout << number[i].getnum() << endl;
            break;
        }
    }
    return 0;
}