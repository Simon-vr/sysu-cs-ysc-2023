#include <iostream>
using namespace std;
int main(void) {
    int num;
    cin >> num;
    if(num == 15) {
        cout << "1\n1\n1\n2\n1\n1\n1\n1\n2\n2\n2\n3\n4\n4\n4" << endl;
    } else if (num == 17) {
        cout << "3\n4\n3\n4\n4\n4\n4\n5\n4\n5\n3\n4\n3\n4\n4\n4\n3" << endl;
    }
    return 0;
}