#include <iostream>
#include <vector>
#include <algorithm>
#include "Graph.h"
using namespace std;

bool cmp_max(int x,int y){
	return x > y;
}

vector<int> degreeSequence(const ALGraph &g) {
    vector<int> result;
    for(int i = 0; i < g.order; i ++) {
        result.push_back(g.adj[i].size());
    }
    sort(result.begin(), result.end(), cmp_max);
    return result;
}