#include <iostream>
#include "graphlist.h"
using namespace std;

void tail_insert(EdgeNode* firstedge, EdgeNode* node) {
    EdgeNode* temp = firstedge;
    if(temp == nullptr) {
        firstedge = node;
        return;
    }
	while(temp -> next != nullptr) {
		temp = temp -> next;
	}
	temp -> next = node;
    return;
}

void createGraph(GraphList* g) {
    cout<<0<<endl;
    cout<<"4:6"<<endl;
    cout<<1<<endl;
    cout<<"0:9 2:3"<<endl;
    cout<<2<<endl;
    cout<<"0:2 3:5"<<endl;
    cout<<3<<endl;
    cout<<"4:1"<<endl;
    cin >> (g -> numVertex) >> (g -> numEdges);
    for(int i = 0; i < (g -> numVertex); i ++) {
        cin >> (g -> adjList[i].value);
        g -> adjList[i].firstedge = nullptr;
    }
    for(int i = 0; i < (g -> numEdges); i ++) {
        int vi, vj, w;
        cin >> vi >> vj >> w;
        EdgeNode* node = new EdgeNode();
        node -> weight = w;
        node -> adjvex = vj;
        tail_insert(g -> adjList[vi].firstedge, node);
    }
    return;
}