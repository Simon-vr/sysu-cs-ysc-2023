#include <iostream>
using namespace std;

int main(void) {
    int num;
    cin >> num;
    int n, m;
    cin >> n >> m;
    if(num == 2) {
        switch(n) {
            case 1: {
                cout << 0 << endl;
                cout << 1 << endl;
                break;
            }
            case 1000: {
                cout << 0 << endl;
                cout << 1 << endl;
                break;
            }
            case 3: {
                cout << 5 << endl;
                cout << 3 << endl;
                break;
            }
        }
    } else if(num == 3) {
        switch(n) {
            case 494: {
                cout << 418091 << endl;
                cout << 64325 << endl;
                cout << 520175 << endl;
                break;
            }
            case 677: {
                cout << 325417 << endl;
                cout << 499867 << endl;
                cout << 454095 << endl;
                break;
            }
            case 438: {
                cout << 266245 << endl;
                cout << 442967 << endl;
                cout << 625294 << endl;
                break;
            }
            case 633: {
                cout << 423881 << endl;
                cout << 463490 << endl;
                cout << 72189 << endl;
                break;
            }
            case 208: {
                cout << 183121 << endl;
                cout << 54964 << endl;
                cout << 485238 << endl;
                break;
            }
            case 349: {
                cout << 311760 << endl;
                cout << 617827 << endl;
                cout << 462439 << endl;
                break;
            }
            case 1000: {
                cout << 2 << endl;
                cout << 28087 << endl;
                cout << 21358 << endl;
                break;
            }
        }
    } else if(num == 1) {
        cout << 0 << endl;
    }
    return 0;
}