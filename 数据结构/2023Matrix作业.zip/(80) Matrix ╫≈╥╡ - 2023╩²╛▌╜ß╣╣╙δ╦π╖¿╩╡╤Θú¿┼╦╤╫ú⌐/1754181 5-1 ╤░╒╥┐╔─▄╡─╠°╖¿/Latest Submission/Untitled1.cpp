#include <iostream>
using namespace std;

class Solution {
public:
    int numWays(int n) {
        return fbnq(n+1);
    }
    //斐波那契数列
    int fbnq(int n)
    {
        int con=1e9+7;
        int first=0;
        int second=1;
        int tem=0;
        while(n-->0)
        {
            tem=first+second;
            first=second%con;
            second=tem%con;
        }
        return first;
    }
};

int main(void) {
    int num;
    cin >> num;
    int result[num] = {0};
    Solution solution;
    for(int i = 0; i < num; i ++) {
        int n;
        cin >> n;
        result[i] = solution.numWays(n);
    }
    for(int i = 0; i < num; i ++) {
        cout << result[i] << endl;
    }
    return 0;
}