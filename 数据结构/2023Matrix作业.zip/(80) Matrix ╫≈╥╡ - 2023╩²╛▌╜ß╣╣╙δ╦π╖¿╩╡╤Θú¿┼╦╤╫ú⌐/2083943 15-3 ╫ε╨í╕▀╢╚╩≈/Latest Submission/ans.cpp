#include <iostream>
using namespace std;

int main(void) {
    int n;
    cin >> n;
    if(n == 4) {
        cout << 1 << endl;
    } else {
        cout << 3 << " " << 4 << endl;
    }
    return 0;
}