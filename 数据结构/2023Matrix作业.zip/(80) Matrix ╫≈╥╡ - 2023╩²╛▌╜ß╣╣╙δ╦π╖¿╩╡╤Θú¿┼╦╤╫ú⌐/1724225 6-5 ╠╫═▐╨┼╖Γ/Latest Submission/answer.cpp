#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

class Solution {
public:

    static bool judge(const pair<int,int> a,const pair<int,int> b){
        if(a.first!=b.first){
            return a.first<b.first;
        }
        return a.second>b.second;
    }
    int get_cur_index(int *dp,int index,int value){
        int left = 1;
        int right = index;
        while(left<right){
            int mid = left+(right-left)/2;
            if(value<dp[mid]){
                right = mid;
            }else if(value>dp[mid]){
                left=mid+1;
            }else if(value==dp[mid]){
                return mid;
            }
        }
        return left;
    }
    int maxEnvelopes(vector<vector<int>>& envelopes) {
          if(envelopes.empty()){
              return 0;
          }
          vector<pair<int,int> >nums;
        for(int i=0;i<envelopes.size();i++){
            nums.push_back(make_pair(envelopes[i][0],envelopes[i][1]));
        }
        sort(nums.begin(),nums.end(),this->judge);
        int dp[envelopes.size()+1];
        dp[1] = nums[0].second;
        int index = 1;

        for(int i=1;i<nums.size();i++){
            if(nums[i].second>dp[index]){
                dp[++index] = nums[i].second;
            }else{
                int new_index = get_cur_index(dp,index,nums[i].second);
                dp[new_index] = nums[i].second;
            }
        }
        return index;
    }
};

int main(void) {
    int num;
    cin >> num;
    vector<vector<int>> envelopes;
    for(int i = 0; i < num; i ++) {
        int width, height;
        cin >> width >> height;
        vector<int> vec{width, height};
        envelopes.push_back(vec);
    }
    Solution solution;
    cout << solution.maxEnvelopes(envelopes) << endl;
}