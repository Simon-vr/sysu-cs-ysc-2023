#include <stdio.h>
#include <stdlib.h>
int findlength(int* a, int N);

int main(void) {
    int T, N;
    scanf("%d", &T);
    for(int i = 0; i < T; i ++) {
        scanf("%d", &N);
        int a[N];
        for(int j = 0; j < N; j ++) {
            scanf("%d", &a[j]);
        }
        printf("%d\n", findlength(a, N));
    }
    return 0;
}

int findlength(int* a, int N) {
    if(N == 0) {
        return 0;
    }
    int max = 0, num = 1;
    for(int i = 0; i < N-1; i ++) {
        if(a[i+1] > a[i]) {
            num ++;
        } else {
            if(num > max) {
                max = num;
            }
            num = 1;
        }
    }
    if(num >= max) {
        max = num;
    }
    return max;
}