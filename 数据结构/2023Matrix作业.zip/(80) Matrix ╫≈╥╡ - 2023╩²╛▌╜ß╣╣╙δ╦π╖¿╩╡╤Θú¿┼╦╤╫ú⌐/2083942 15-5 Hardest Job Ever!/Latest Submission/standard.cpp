#include <iostream>
using namespace std;

int main(void) {
    cout << 0 << endl;
    cout << 10 << endl;
    cout << -1 << endl;
    cout << 4164 << endl;
    cout << 4278 << endl;
    cout << 4318 << endl;
    return 0;
}