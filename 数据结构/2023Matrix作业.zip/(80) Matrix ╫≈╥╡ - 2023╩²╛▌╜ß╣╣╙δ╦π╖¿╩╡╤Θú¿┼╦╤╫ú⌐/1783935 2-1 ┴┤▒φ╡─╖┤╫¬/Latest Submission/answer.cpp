#include <stdio.h>
#include <stdlib.h>
#include "ListNode.h"

ListNode *reverseList(ListNode *L) {
    ListNode* pre, *p = L -> next, *r = p -> next;
    p -> next = NULL;
    while(r != NULL) {
        pre = p;
        p = r;
        r = r -> next;
        p -> next = pre;
    }
    L -> next = p;
    return L;
}