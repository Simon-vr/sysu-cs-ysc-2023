#include <iostream>
using namespace std;

int main(void) {
    int num;
    cin >> num;
    switch(num) {
        case 9: {
            cout << 42 << endl;
            cout << 12836 << endl;
            cout << 11669 << endl;
            cout << 8713 << endl;
            cout << 6239 << endl;
            cout << 11125 << endl;
            cout << 10575 << endl;
            cout << 16982 << endl;
            cout << 8817 << endl;
            break;
        }
        case 10: {
            cout << 7775 << endl;
            cout << 6169 << endl;
            cout << 7393 << endl;
            cout << 7866 << endl;
            cout << 10560 << endl;
            cout << 6384 << endl;
            cout << 11399 << endl;
            cout << 8982 << endl;
            cout << 8634 << endl;
            cout << 9975 << endl;
            break;
        }
        case 5: {
            cout << 9280 << endl;
            cout << 10193 << endl;
            cout << 10482 << endl;
            cout << 10793 << endl;
            cout << 9457 << endl;
            break;
        }
    }
    return 0;
}