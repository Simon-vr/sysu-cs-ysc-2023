#include<iostream>
#include<stdio.h>

#define INF 20000000
#define MAXN 105

using namespace std;

int P,R,N,M;
int adjacency[MAXN][MAXN];

void buildGraph() {  
    int u,v,w;
    // m = 0;
    // scanf("%d%d",&N,&M);
    N = P;
    M = R;
    for(int i = 1; i <= N; i++) {
        for(int j = 1; j <= N; j++) {
            adjacency[i][j] = INF;
            if(i == j) adjacency[i][j] = 0;
        }
    }

    while(M--) {  
        scanf("%d%d%d",&u,&v,&w);
        // addEdge
        if(w < adjacency[u][v] && w < adjacency[v][u])
            adjacency[u][v] = adjacency[v][u] = w;
    }
}

int MST(int st, int ed) {
    bool component[MAXN];
    int distance[MAXN];
    int neighbor[MAXN];
    for(int i = 1; i <= N; i++){
        component[i] = false;
        distance[i] = adjacency[st][i];
        neighbor[i] = st;
    }
    component[st] = true;
    int new_node;
    for(int i = 2; i <= N; i++) {
        int min = INF;
        new_node = st;
        for(int j = 1; j <= N; j++) {
            if(!component[j]) {
                if(distance[j] < min) {
                    new_node = j;
                    min = distance[j];
                }
            }
        }
        if(min < INF) {
            component[new_node] = true;
            for(int j = 1; j <= N; j++) {
                if(!component[j]) {
                    if(adjacency[new_node][j] < distance[j]) {
                        distance[j] = adjacency[new_node][j];
                        neighbor[j] = new_node;
                    }
                }
            }
        }
        else break;
    }
    int dis_sum = 0;
    for(int i = 1; i <= N; i++) {
        dis_sum += distance[i];
    }
    return dis_sum;
}

int main() {
    for(scanf("%d", &P); P!=0; scanf("%d", &P)) {
        scanf("%d", &R);
        buildGraph();  
        printf("%d\n", MST(1,N));
    }  
    return 0;  
}