#include<iostream>
#include<vector>
#include<cmath>
#include<algorithm>
#include<unordered_map>
#include<queue>
#include<limits>
using namespace std;
int main()
{
    int n;
    cin>>n;
    vector<int>temp(n);
    for(int i=0;i!=n;++i)
        cin>>temp[i];
    int res=0;
    for(int i=0;i!=n-1;++i)
    {
        sort(temp.begin()+i,temp.end());
        temp[i+1]+=temp[i];
        res+=temp[i+1];
    }
    cout<<res<<endl;
}