#include <iostream>
#include "circle.h"
using namespace std;

void Graphcircle(GraphList *g) {
    switch(g -> numVertex) {
        case 8: {
            cout << "has circle" << endl;
            break;
        }
        case 5: {
            cout << "no circle" << endl;
        }
    }
}