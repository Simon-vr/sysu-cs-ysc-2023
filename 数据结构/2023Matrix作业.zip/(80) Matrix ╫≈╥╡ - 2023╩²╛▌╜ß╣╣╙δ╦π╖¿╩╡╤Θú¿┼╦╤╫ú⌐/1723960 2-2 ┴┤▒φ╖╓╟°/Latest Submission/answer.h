#include "ListNode.h"

ListNode* partList(ListNode* list, int x) {
    if(list == NULL) {
        return list;
    }
    ListNode* before_head = new ListNode(0);
    ListNode* after_head = new ListNode(0);
    ListNode* before = before_head;
    ListNode* after = after_head;
    int bh = 0, ah = 0;
    while(list != NULL) {
        if(bh == 0 && list -> val < x) {
            before_head = list;
            list = list -> next;
            bh = 1;
            continue;
        }
        if(ah == 0 && list -> val >= x) {
            after_head = list;
            after = after_head;
            list = list -> next;
            ah = 1;
            continue;
        }

        if(list -> val < x) {
            before -> next = list;
            before = before -> next;
        } else if(list -> val >= x) {
            after -> next = list;
            after = after -> next;
        }
        list = list -> next;
    }
    before -> next = after_head;
    after -> next = NULL;
    return before_head;
}