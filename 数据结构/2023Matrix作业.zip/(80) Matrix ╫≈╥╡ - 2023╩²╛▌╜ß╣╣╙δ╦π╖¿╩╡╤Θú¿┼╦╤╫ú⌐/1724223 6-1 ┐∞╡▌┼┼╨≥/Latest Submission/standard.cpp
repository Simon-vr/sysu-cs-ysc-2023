#include<iostream>
using namespace std;
int main(){
    int N,n,num,max,times;
    cin>>N;
    for(int i=0;i<N;i++){
        times=0;
        cin>>n;
        cin>>max;
        for(int i=1;i<n;i++){
            cin>>num;
            if(max<num){
                max=num;  
            }
            else{
                times+=5;                
            }
        }  
        cout<<times<<endl;   
    }
    return 0;    
}