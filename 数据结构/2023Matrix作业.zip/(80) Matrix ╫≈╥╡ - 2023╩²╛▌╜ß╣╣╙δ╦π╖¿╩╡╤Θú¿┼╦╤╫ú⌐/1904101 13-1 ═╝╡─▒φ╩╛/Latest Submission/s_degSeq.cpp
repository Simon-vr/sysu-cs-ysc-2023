#include <iostream>
#include "Graph.h"
using namespace std;

ALGraph mkGraph() {
    int n, m;
    cin >> n >> m;
    ALGraph* algraph = new ALGraph(n, m);
    
    int a, b;
    for(int i = 0; i < m; i ++) {
        cin >> a >> b;
        algraph -> adj[a].push_back(b);
        algraph -> adj[b].push_back(a);
    }
    return *algraph;
}