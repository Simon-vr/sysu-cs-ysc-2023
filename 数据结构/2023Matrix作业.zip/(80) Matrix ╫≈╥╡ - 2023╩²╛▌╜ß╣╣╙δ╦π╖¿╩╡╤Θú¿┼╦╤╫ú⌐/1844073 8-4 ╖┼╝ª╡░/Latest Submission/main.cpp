#include <cstdio>
#include <cctype>
int list[100001];
void divide(int n, int m, int max) {
    if (m >= max)
        return;
    if (m == 0 || list[m] <= list[m-1]) {
        int i;
        for (i = 0; i <= m; i++) {
            printf("%d", list[i]);
        }
        for (;i < max; i++) {
            printf("0");
        }
        printf("\n");
    }
    for (int i = n-1; i >= 1; i--) {
        list[m] = i;
        list[m+1] = n-i;
        if (m == 0 || list[m] <= list[m-1]) {
                divide(n-i, m+1, max);
        }
    }

}
int main() {
    int n, m, b;
    scanf("%d", &n);
    for (int i = 0; i < n; i++) {
        scanf("%d%d", &m, &b);
        list[0] = m;
        divide(m, 0, b);
    }
    return 0;
}               