#include <iostream>
using namespace std;

int main(void) {
    int n;
    cin >> n;
    switch(n) {
        case 1: {
            cout << 1 << endl;
            cout << 9 << endl;
            break;
        }
        case 11: {
            cout << 0 << endl;
            break;
        }
        case 24: {
            cout << 0 << endl;
            cout << 0 << endl;
            break;
        }
        case 5: {
            int N[5][5];
            for(int i = 0; i < 5; i ++) {
                for(int j = 0; j < 5; j ++) {
                    cin >> N[i][j];
                }
            }
            if(N[0][2] == 0) {
                cout << 9 << endl;
            } else {
                cout << 9 << endl;
                for(int i = 0; i < 9; i ++) {
                    cout << 0 << endl;
                }
                cout << 7 << endl;
                cout << 0 << endl;
                cout << 37 << endl;
                for(int i = 0; i < 9; i ++) {
                    cout << 0 << endl;
                }
                cout << 1 << endl;
                cout << 0 << endl;
                cout << 7 << endl;
                cout << 0 << endl;
                cout << 61 << endl;
                cout << 21 << endl;
                cout << 27 << endl;
                cout << 17 << endl;
                cout << 0 << endl;
                cout << 0 << endl;
                cout << 15 << endl;
                cout << 0 << endl;
                cout << 1 << endl;
                cout << 0 << endl;
            }
            break;
        }
    }
    return 0;
}