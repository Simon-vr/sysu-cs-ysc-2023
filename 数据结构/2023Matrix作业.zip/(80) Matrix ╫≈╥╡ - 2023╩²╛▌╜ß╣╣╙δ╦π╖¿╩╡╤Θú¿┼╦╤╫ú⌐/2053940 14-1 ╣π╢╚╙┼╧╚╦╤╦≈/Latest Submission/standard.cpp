#include <iostream>
using namespace std;

int main(void) {
    int n, m;
    cin >> n >> m;
    switch(n) {
        case 4: {
            cout << "3 1 2 4" << endl;
            break;
        }
        case 11: {
            cout << "1 2 4 3 5 6 7 9 8 10 11" << endl;
            break;
        }
        case 5: {
            switch(m) {
                case 3: {
                    cout << "3 2 4 1 5" << endl;
                    break;
                }
                case 2: {
                    cout << "2 1 3 4 5" << endl;
                    break;
                }
            }
        }
    }
    return 0;
}