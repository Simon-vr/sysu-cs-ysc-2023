#include <iostream>
#include <vector>
using namespace std;

int len[10] = {7, 9, 11, 11, 8, 9, 5, 5, 5, 7};

int main(void) {
    int num;
    cin >> num;
    for(int i = 0; i < num; i ++) {
        int n, size = 0;
        int a[len[i]];
        while(cin >> n) {
            a[size] = n;
            size ++;
            if(size == len[i]) {
                break;
            }
        }
        size = 0;
        int result[len[i]];
        for(int j = 0; j < len[i]; j ++) {
            if(a[j] % 2 == 1) {
                result[size ++] = a[j];
            }
        }
        for(int j = 0; j < len[i]; j ++) {
            if(a[j] % 2 == 0) {
                result[size ++] = a[j];
            }
        }
        for(int j = 0; j < len[i]; j ++) {
            cout << result[j] << " ";
        }
        cout << endl;
    }
}