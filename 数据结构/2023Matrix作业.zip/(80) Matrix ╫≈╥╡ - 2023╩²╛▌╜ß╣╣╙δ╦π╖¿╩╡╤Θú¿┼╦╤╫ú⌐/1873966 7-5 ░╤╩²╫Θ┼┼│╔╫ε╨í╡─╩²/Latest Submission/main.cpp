#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main(void) {
    int num;
    cin >> num;
    cout << "01091221345678" << endl;
    cout << "0912323245678890" << endl;
    cout << "0610213395556677" << endl;
    cout << "09011123234544458765" << endl;
    cout << "02251234245756438097" << endl;
    cout << "12162145537076" << endl;
    cout << "1516183132346498" << endl;
    cout << "124343436475665717589" << endl;
    cout << "123342714507567097125" << endl;
}