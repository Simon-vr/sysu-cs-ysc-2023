#include <iostream>
using namespace std;

class Queue {
    private:
        int* num;
        int length;
    public:
        Queue() : length(0) {
            this -> num = new int[10000];
        }
        ~Queue() {
            delete[] this -> num;
        }
        void in(int n) {
            this -> num[length] = n;
            length ++;
        }
        void out(int& n) {
            if(length == 0){
                n = -1;
            } else {
                length --;
                n = this -> num[0];
                for(int i = 0; i < length; i ++) {
                    this -> num[i] = this -> num[i+1];
                }
            }
        }
        int count() {
            return this -> length;
        }
};

int main(void) {
    Queue* queue = new Queue();
    int n;
    cin >> n;
    for(int i = 0; i < n; i ++) {
        string order;
        cin >> order;
        if(order == "In") {
            int x;
            cin >> x;
            queue -> in(x);
        } else if(order == "Out") {
            int x;
            queue -> out(x);
            cout << x << endl;
        } else if(order == "Count") {
            cout << queue -> count() << endl;
        }
    }
    return 0;
}