#include <iostream>
#include <vector>
using namespace std;

int find_min(vector<int> num, vector<bool> flag) {
    int temp = -1;
    for(int i = 0; i < num.size(); i ++) {
        if(flag[i]) {
            continue;
        }
        if(!flag[i] && temp == -1) {
            temp = i;
        }
        if(temp != -1 && num[temp] >= num[i]) {
            temp = i;
        }
    }
    return temp;
}

class Node {
    public:
        int name, weight;
        Node(int name, int weight) {
            this -> name = name;
            this -> weight = weight;
        }
};

class Graph {
    private:
        int node, edge;
        vector<vector<Node*>> adj;
    public:
    Graph(int node, int edge) {
        this -> node = node;
        this -> edge = edge;
        this -> adj.resize(node);
    }
    void mkGraph(int x, Node* y) {
        this -> adj[x].push_back(y);
    }
    vector<int> dijkstra(int x) {
        x -= 1;
        vector<int> path, dist;
        vector<bool> finally;
        path.resize(node);
        dist.resize(node);
        finally.resize(node);
        for(int i = 0; i < node; i ++) {
            finally[i] = false;
            dist[i] = 65535;
            path[i] = -1;
        }
        dist[x] = 0; 
        for(int i = 0; i < node; i ++) {
            int min = find_min(dist, finally);
            finally[min] = true;
            for(int j = 0; j < adj[min].size(); j ++) {
                if(!finally[adj[min][j] -> name]) {
                    int temp = adj[min][j] -> weight + dist[min];
                    if(temp < dist[adj[min][j] -> name]) {
                        dist[adj[min][j] -> name] = temp;
                        path[adj[min][j] -> name] = min;
                    }
                }
            }
            /*
            for(int j = 0; j < node; j ++) {
                cout << dist[j] << " ";
            }
            cout << endl;
            */
        }

        return dist;
    }
};

int main(void) {
    int num;
    cin >> num;
    for(int test_case = 0; test_case < num; test_case ++) {
        int node, edge, origin;
        cin >> node >> edge;
        Graph* graph = new Graph(node, edge);
        for(int i = 0; i < edge; i ++) {
            int x, y, w;
            cin >> x >> y >> w;
            x -= 1;
            y -= 1;
            Node* node = new Node(y, w);
            graph -> mkGraph(x, node);
        }
        cin >> origin;
        vector<int> dist = graph -> dijkstra(origin);
        for(int i = 0; i < node; i ++) {
            if(dist[i] == 65535) {
                continue;
            }
            cout << origin << "-" << i+1 << ":" << dist[i] << endl;
        }
    }
    return 0;
}