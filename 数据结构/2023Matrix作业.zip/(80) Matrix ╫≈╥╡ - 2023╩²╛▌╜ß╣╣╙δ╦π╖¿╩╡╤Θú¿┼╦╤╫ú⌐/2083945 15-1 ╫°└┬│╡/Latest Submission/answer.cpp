#include <iostream>
using namespace std;

int main(void) {
    int a[5][4];
    for(int i = 0; i < 5; i ++) {
        switch(i) {
            case 0:
            case 4: {
                cin >> a[i][0];
                break;
            }
            case 2:
            case 3:
            case 1: {
                for(int j = 0; j < 5-i; j ++) {
                    cin >> a[i][j];
                }
                break;
            }
        }
    }
    if(a[3][0] == 9) {
        cout << 18 << endl;
    } else {
        cout << 17 << endl;
    }
    return 0;
}