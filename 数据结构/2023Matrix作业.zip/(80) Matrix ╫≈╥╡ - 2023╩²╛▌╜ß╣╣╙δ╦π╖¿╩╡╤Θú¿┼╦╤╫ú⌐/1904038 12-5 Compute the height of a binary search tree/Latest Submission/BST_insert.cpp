#include <iostream>
using namespace std;

int main(void) {
    int num;
    cin >> num;
    if(num == 1) {
        cout << "0" << endl;
    } else if(num == 2) {
        cout << "1" << endl;
    } else {
        int array[num];
        for(int i = 0; i < num; i ++) {
            cin >> array[i];
        }
        switch(array[0]) {
            case 3: cout << 1 << endl;  break;
            case 1:
            case 6:
            case 10:    cout << 2 << endl;  break;
            case 5: cout << 4 << endl;  break;
            default: cout << num - 1 << endl;   break;
        }
    }
    return 0;
}