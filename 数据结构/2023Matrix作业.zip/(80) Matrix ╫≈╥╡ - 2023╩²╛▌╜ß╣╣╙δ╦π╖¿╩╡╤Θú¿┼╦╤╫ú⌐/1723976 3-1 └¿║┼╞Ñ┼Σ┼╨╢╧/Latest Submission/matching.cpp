#include <iostream>
#include <string>
#include <cstring>
#include <stack>
using namespace std;

bool match(const string & line) {
    int len = line.length();
    char* ch = const_cast<char*>(line.c_str());
    stack<char> check;
    for(int i = 0; i < len; i ++) {
        if(i == 0 && (ch[i] == ')' || ch[i] == ']' || ch[i] == '}')) {
            return false;
        }
        if(ch[i] == '(' || ch[i] == '[' || ch[i] == '{') {
            check.push(ch[i]);
        } else if(ch[i] == ')') {
            if(check.empty()) {
                return false;
            }
            if(check.top() == '(') {
                check.pop();
            }
        } else if(ch[i] == ']') {
            if(check.empty()) {
                return false;
            }
            if(check.top() == '[') {
                check.pop();
            }
        } else if(ch[i] == '}') {
            if(check.empty()) {
                return false;
            }
            if(check.top() == '{') {
                check.pop();
            }
        }
    }
    return check.empty();
}