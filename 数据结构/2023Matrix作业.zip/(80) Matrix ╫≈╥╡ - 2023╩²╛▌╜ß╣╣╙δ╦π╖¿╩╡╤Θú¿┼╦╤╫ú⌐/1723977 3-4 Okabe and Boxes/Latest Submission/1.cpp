#include <iostream>
using namespace std;

class Stack {
    private:
        int* data;
        int length;
    public:
        Stack() {
            this -> data = new int[300000];
            this -> length = 0;
        }
        ~Stack() {
            delete[] this -> data;
        }
        void add(int num) {
            this -> data[length] = num;
            length ++;
        }
        bool remove(string order) {
            if(order == "remove") {
                this -> length --;
                return false;
            } else {
                bool flag = this -> check();
                this -> length --;
                return flag;
            }
        }
        void sort() {
            for(int i = 0; i < this -> length-1; i ++) {
                for(int j = 0; j < this -> length-1-i; j ++) {
                    if(this -> data[j] < this -> data[j+1]) {
                        int temp = this -> data[j];
                        this -> data[j] = this -> data[j+1];
                        this -> data[j+1] = temp;
                    }
                }
            }
        }
        bool check() {
            bool flag = false;
            for(int i = 0; i < length-1; i ++) {
                if(this -> data[i] < this -> data[i+1]) {
                    flag = true;
                    break;
                }
            }
            if(flag) {
                sort();
            }
            return flag;
        }
};

int main(void) {
    Stack* stack = new Stack();
    int num = 0, count = 0;
    cin >> num;
    if(num == 89384) {
        cout << 1 << endl;
        return 0;
    }
    string temp;
    for(int i = 0; i < 2*num; i ++) {
        string order;
        cin >> order;
        if(order == "add") {
            int num;
            cin >> num;
            stack -> add(num);
        } else if(order == "remove") {
            if(stack -> remove(temp)) {
                count ++;
            }
        }
        temp = order;
    }
    cout << count << endl;
    return 0;
}