#include "TreeNode.h"
#include<iostream>
using namespace std;

int maxAns;

/* 0 => left, 1 => right */
void dfs(TreeNode* o, bool dir, int len)
{
    maxAns = max(maxAns, len);
    if (!dir)
    {
        if (o->left) dfs(o->left, 1, len + 1);
        if (o->right) dfs(o->right, 0, 1);
    }
    else
    {
        if (o->right) dfs(o->right, 0, len + 1);
        if (o->left) dfs(o->left, 1, 1);
    }
}

int longestZigZag(TreeNode* root)
{
    if (!root) return 0;
    maxAns = 0;
    dfs(root, 0, 0);
    dfs(root, 1, 0);
    return maxAns;
}

