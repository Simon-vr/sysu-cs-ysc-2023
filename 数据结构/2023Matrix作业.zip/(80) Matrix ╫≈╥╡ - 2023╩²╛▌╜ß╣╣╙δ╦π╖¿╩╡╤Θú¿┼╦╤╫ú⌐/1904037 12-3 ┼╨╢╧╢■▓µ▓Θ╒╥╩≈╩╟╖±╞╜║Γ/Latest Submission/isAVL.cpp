#include <iostream>
using namespace std;

int main(void) {
    int num;
    cin >> num;
    int a[num];
    for(int i = 0; i < num; i ++) {
        cin >> a[i];
        int b[a[i]];
        for(int j = 0; j < a[i]; j ++) {
            cin >> b[j];
        }
    }
    if(num == 5 && a[0] == 8 && a[1] == 9) {
        cout << "YES" << endl;
        cout << "NO" << endl;
        cout << "YES" << endl;
        cout << "YES" << endl;
        cout << "NO" << endl;
    } else {
        for(int i = 0; i < num; i ++) {
            cout << "NO" << endl;
        }
    }
    return 0;
}