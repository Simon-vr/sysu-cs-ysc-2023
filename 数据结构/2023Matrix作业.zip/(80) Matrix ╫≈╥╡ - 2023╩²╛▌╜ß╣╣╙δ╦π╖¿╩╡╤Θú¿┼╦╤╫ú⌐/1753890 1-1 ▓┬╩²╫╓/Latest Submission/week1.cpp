#include <iostream>
using namespace std;

int main(void) {
    int t;
    int A[3], B[3];
    int count = 0;
    cin >> t;
    for(int i = 0; i < t; i ++) {
        cin >> A[0] >> A[1] >> A[2];
        cin >> B[0] >> B[1] >> B[2];
        if(A[0] == B[0])    count ++;
        if(A[1] == B[1])    count ++;
        if(A[2] == B[2])    count ++;
        cout << count << endl;
        count = 0;
    }
}