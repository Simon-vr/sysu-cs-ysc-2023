#include <iostream>
using namespace std;

class Node {
    public:
        int key;
        Node* next;
        Node(int key) : key(key), next(NULL) {}
};

class Hash {
    private:
        Node* nodes[13];
        int length[13];
    public:
        Hash() {
            for(int i = 0; i < 13; i ++) {
                this -> nodes[i] = new Node(-1);
                this -> length[i] = 0;
            }
        }
        void TailInsert(Node* node) {
            int key = node -> key;
            key %= 13;
            Node* temp = this -> nodes[key];
            for(int i = 0; i < this -> length[key]; i ++) {
                temp = temp -> next;
            }
            temp -> next = node;
            this -> length[key] ++;
        }
        void Push(int key) {
            Node* node = new Node(key);
            TailInsert(node);
        }
        void Print() {
            for(int i = 0; i < 13; i ++) {
                cout << i << "#";
                Node* temp = this -> nodes[i] -> next;
                for(int j = 0; j < this -> length[i]; j ++) {
                    cout << temp -> key << " ";
                    temp = temp -> next;
                }
                if(this -> length[i] == 0) {
                    cout << "NULL";
                }
                cout << endl;
            }
        }
};

int main(void) {
    while(1) {
        int num, key;
        cin >> num;
        Hash* hash = new Hash();
        if(num == 0) {
            break;
        }
        for(int i = 0; i < num; i ++) {
            cin >> key;
            if(key == 0) {
                break;
            }
            hash -> Push(key);
        }
        hash -> Print();
        if(key == 0) {
            break;
        }
        delete hash;
    }
    return 0;
}