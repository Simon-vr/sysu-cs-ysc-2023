pair<pair<bool, size_t>, int>  lookup(const Table& t, const Key k) {
    
}
