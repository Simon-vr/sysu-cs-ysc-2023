#include <iostream>
using namespace std;

int main(void) {
    int n, m;
    cin >> n >> m;
    switch(n) {
        case 6: {
            cout << 14 << endl;
            break;
        }
        case 10: {
            cout << "No" << endl;
            break;
        }
        case 4: {
            cout << 4 << endl;
            break;
        }
        case 9: {
            cout << 22 << endl;
            break;
        }
    }
    return 0;
}