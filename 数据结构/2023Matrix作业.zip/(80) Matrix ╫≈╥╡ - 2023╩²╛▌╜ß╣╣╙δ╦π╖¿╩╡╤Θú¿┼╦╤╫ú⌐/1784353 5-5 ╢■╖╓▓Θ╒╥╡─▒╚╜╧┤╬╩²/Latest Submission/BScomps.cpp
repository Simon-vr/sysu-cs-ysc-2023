#include <iostream>
#include <vector>
#include <utility>
using namespace std;

pair<bool, int> binary_search(vector<int> list, int target) {
    if(list.empty()) {
        pair<bool, int> pai(0, 0);
        return pai;
    } else if(list.size() == 1) {
        if(target == list[0]) {
            pair<bool, int> pai(1, 1);
            return pai;
        } else {
            pair<bool, int> pai(0, 1);
            return pai;
        }
    } else {
        int mid = (list.size() -1) / 2 ;
        if(list[mid] < target) {
            for(int i = 0; i <= mid; i ++) {
                list.erase(list.begin());
            }
            pair<bool, int> pai = binary_search(list, target);
            pair<bool, int> result(pai.first, ((pai.second)+1));
            return result;
        } else {
            int size = list.size();
            for(int i = mid+1; i < size; i ++) {
                list.pop_back();
            }
            pair<bool, int> pai = binary_search(list, target);
            pair<bool, int> result(pai.first, ((pai.second)+1));
            return result;
        }
    }
}