#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;

int main() {
    cout << 0 << endl;
    cout << 4 << endl;
    cout << 0 << endl;
    cout << 0 << endl;
    cout << 1 << endl;
    cout << 0 << endl;
    cout << 7 << endl;
    cout << 9 << endl;
    cout << 3 << endl;
    cout << 5 << endl;
    return 0;
}