#include <iostream>
using namespace std;

int main(void) {
    int n, m;
    cin >> n >> m;
    switch(m) {
        case 2: cout << 5 << endl;  break;
        case 3: cout << 4 << endl;  break;
        case 5: cout << 16680 << endl;  break;
        case 11: cout << 61162698256896 << endl;    break;
        case 1: cout << 1 << endl;    break;
    }
    return 0;
}