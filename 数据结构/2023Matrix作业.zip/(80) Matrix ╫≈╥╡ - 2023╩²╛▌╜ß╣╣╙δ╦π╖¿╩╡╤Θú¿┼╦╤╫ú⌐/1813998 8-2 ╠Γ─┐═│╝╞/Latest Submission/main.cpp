#include <iostream>
using namespace std;

class Question {
    private:
        int num;
        int pass, unpass;
    public:
        Question() : num(0), pass(0), unpass(0) {}
        void setnum(int num) {
            this -> num = num;
        }
        void passque() {
            this -> pass ++;
        }
        void unpassque() {
            this -> unpass ++;
        }
        int getnum() {
            return this -> num;
        }
        int getpass() {
            return this -> pass;
        }
        int getunpass() {
            return this -> unpass;
        }
};

class Student {
    private:
        int id;
        Question* que;
    public:
        Student() : id(0), que(NULL) {};
        void setid(int id) {
            this -> id = id;
        }
        void setque(Question* que) {
            this -> que = que;
        }
        int getid() {
            return this -> id;
        }
        Question* getque() {
            return this -> que;
        }
};

int main(void) {
    int A, B;
    cin >> A >> B;
    Student* stu = new Student[A];
    for(int i = 0; i < A; i ++) {
        stu[i].setid(i+1);
        Question* que = new Question[B];
        for(int j = 0; j < B; j ++) {
            que[j].setnum(j+1);
        }
        stu[i].setque(que);
    }
    int* result = new int[3];
    while(cin >> result[0] >> result[1] >> result[2]) {
        for(int i = 0; i < A; i ++) {
            if(stu[i].getid() == result[0]) {
                for(int j = 0; j < B; j ++) {
                    if(stu[i].getque()[j].getnum() == result[1]) {
                        if(result[2] == 0) {
                            stu[i].getque()[j].unpassque();
                        } else if(result[2] == 1) {
                            stu[i].getque()[j].passque();
                        }
                    }
                }
            }
        }
    }
    for(int i = 0; i < A; i ++) {
        for(int j = 0; j < B; j ++) {
            cout << stu[i].getque()[j].getpass() << " " << stu[i].getque()[j].getunpass() << " ";
        }
        cout << endl;
    }
    return 0;
}