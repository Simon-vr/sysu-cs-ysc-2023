#include <iostream>
using namespace std;

class Struct {
    private:
        int num1, num2;
        int sum;
    public:
        Struct() : num1(0), num2(0), sum(0) {}
        Struct(int n1, int n2): num1(n1), num2(n2), sum(n1+n2) {}
        Struct& operator = (const Struct& other) {
            this -> num1 = other.num1;
            this -> num2 = other.num2;
            this -> sum = other.sum;
            return (*this);
        }
        int getsum() {
            return this -> sum;
        }
        void print() {
            cout << num1 << "," << num2 << " ";
        }
};

void sort(Struct* sum, int length) {
    for(int i = 0; i < length-1; i ++) {
        for(int j = 0; j < length-1-i; j ++) {
            if(sum[j].getsum() > sum[j+1].getsum()) {
                Struct temp = sum[j];
                sum[j] = sum[j+1];
                sum[j+1] = temp;
            }
        }

    }
}

int main(void) {
    int k, m, n;
    cin >> k >> m >> n;
    int nums1[m], nums2[n];
    for(int i = 0; i < m; i ++) {
        cin >> nums1[i];
    }
    for(int i = 0; i < n; i ++) {
        cin >> nums2[i];
    }
    Struct* sum = new Struct[m*n];
    for(int i = 0; i < m; i ++) {
        for(int j = 0; j < n; j ++) {
            sum[i*n+j] = *(new Struct(nums1[i], nums2[j]));
        }
    }
    sort(sum, m*n);
    for(int i = 0; i < k; i ++) {
        sum[i].print();
    }
    cout << endl;
    return 0;
}