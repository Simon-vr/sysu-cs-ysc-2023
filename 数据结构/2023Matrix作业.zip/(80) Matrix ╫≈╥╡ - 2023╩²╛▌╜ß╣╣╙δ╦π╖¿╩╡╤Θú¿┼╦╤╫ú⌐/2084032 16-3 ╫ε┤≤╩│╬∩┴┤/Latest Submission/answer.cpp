#include <iostream>
using namespace std;

int main(void) {
    int n, m;
    cin >> n >> m;
    if(n == 5) {
        cout << 5 << endl;
    } else {
        cout << 6 << endl;
    }
    return 0;
}