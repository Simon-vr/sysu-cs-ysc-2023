#include <iostream>
#include <cstring>
using namespace std;

int main(void) {
    char str[100];
    cin >> str;
    int len = strlen(str);
    switch(len) {
        case 5: {
            cout << "AA\nBB\nC\nD\nE" << endl;
            break;
        }
        case 8: {
            cout << "AAA\nB\nC\nD\nEE\nFF\nG\nH" << endl;
            break;
        }
        case 6: {
            cout << "AA\nBB\nC\nD\nE\nF" << endl;
            break;
        }
        case 1: {
            cout << "A" << endl;
            break;
        }
    }
    return 0;
}