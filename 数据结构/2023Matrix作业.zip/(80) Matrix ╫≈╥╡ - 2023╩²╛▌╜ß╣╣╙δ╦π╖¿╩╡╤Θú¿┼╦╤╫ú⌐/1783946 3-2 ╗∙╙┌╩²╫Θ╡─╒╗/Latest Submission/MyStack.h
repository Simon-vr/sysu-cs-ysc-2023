#include <iostream>
using namespace std;

enum ErrorCode {
	success,
	underflow,
	overflow
};

const int maxStack = 100;

template <typename T>
class MyStack {
public:
	MyStack() {
        this -> size = 0;
        T* entry = new T[maxStack];
        for(int i = 0; i < maxStack; i ++) {
            this -> entry[i] = entry[i];
        }
    }
	
	bool empty() const {
        if(this -> size == 0) {
            return true;
        }
        return false;
    }
	
	ErrorCode pop() {
        if(this -> size == 0) {
            return underflow;
        }
        this -> size --;
        return success;
    }
	
	ErrorCode top(T &item) const {
        if(this -> size == 0) {
            return underflow;
        }
        item = this -> entry[size - 1];
        return success;
    }
	
	ErrorCode push(const T &item) {
        if(this -> size == maxStack) {
            return overflow;
        }
        this -> entry[size] = item;
        size ++;
        return success;
    }

private:
	int size;
	T entry[maxStack];
};