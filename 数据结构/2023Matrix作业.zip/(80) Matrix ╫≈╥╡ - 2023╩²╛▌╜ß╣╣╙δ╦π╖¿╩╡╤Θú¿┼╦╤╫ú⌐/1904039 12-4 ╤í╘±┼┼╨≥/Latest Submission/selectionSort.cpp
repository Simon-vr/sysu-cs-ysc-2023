#include <iostream>
using namespace std;

int main(void) {
    int num;
    cin >> num;
    for(int i = 0; i < num; i ++) {
        int n;
        cin >> n;
        int a[n];
        for(int j = 0; j < n; j ++) {
            cin >> a[j];
        }
        for(int j = 0; j < n - 1; j ++) {
            int temp, min = j;
            for(int k = j; k < n; k ++) {
                if(a[min] > a[k]) {
                    min = k;
                }
            }
            temp = a[min];
            a[min] = a[j];
            a[j] = temp;
            for(int k = 0; k < n; k ++) {
                cout << a[k] << " ";
            }
            cout << endl;
        }
    }
    return 0;
}