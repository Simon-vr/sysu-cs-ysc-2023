#include <iostream>
#include "ListNode.h"
using namespace std;

bool isPalindrome(ListNode* head) {
    if(head->next == nullptr||head == nullptr)
        return true;
    struct ListNode *slow = head;
    struct ListNode *fast = head;
    struct ListNode *rhead = nullptr;
    struct ListNode *store;
    while(fast->next != nullptr && fast->next->next != nullptr){
            slow = slow->next;
            fast = fast->next->next;
    }
    slow = slow->next;
    while(slow != nullptr){
        store = slow->next;
        slow->next = rhead;
        rhead = slow;
        slow = store;
    }
    while(rhead != nullptr){
        if(rhead->val != head->val)
            return false;
        rhead = rhead->next;
        head = head->next;
    }
    return true;
}