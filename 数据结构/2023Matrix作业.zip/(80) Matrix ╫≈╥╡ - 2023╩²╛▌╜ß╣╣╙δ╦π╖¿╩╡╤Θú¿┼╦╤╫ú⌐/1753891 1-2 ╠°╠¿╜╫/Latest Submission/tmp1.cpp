#include <iostream>
using namespace std;
int jump(int num);

int main(void) {
    int t, stairs;
    cin >> t;
    for(int i = 0; i < t; i ++) {
        cin >> stairs;
        cout << jump(stairs) << endl;
    }
}

int jump(int num) {
    if(num <= 2) {
        return num;
    }
    return jump(num-1) + jump(num-2);
}