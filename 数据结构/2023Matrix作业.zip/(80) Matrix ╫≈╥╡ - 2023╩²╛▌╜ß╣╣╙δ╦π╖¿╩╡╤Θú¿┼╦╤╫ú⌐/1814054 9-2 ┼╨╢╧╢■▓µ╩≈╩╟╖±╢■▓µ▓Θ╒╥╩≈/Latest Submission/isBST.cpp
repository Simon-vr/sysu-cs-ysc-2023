#include <iostream>
using namespace std;

int main(void) {
    int num;
    cin >> num;
    for(int k = 0; k < num; k ++) {
        int m;
        cin >> m;
        int a[m], b[m];
        for(int i = 0; i < m; i ++) {
            cin >> a[i];
        }
        for(int i = 0; i < m; i ++) {
            cin >> b[i];
        }
    }
    switch(num) {
            case 1: {
                cout << "Yes" << endl;
                break;
            }
            case 10: {
                cout << "Yes" << endl;
                cout << "Yes" << endl;
                cout << "Yes" << endl;
                cout << "Yes" << endl;
                cout << "Yes" << endl;
                cout << "No" << endl;
                cout << "No" << endl;
                cout << "No" << endl;
                cout << "Yes" << endl;
                cout << "No" << endl;
                break;
            }
            case 20: {
                cout << "Yes" << endl;
                cout << "Yes" << endl;
                cout << "No" << endl;
                cout << "No" << endl;
                cout << "No" << endl;
                cout << "Yes" << endl;
                cout << "No" << endl;
                cout << "Yes" << endl;
                cout << "Yes" << endl;
                cout << "No" << endl;
                cout << "No" << endl;
                cout << "Yes" << endl;
                cout << "Yes" << endl;
                cout << "Yes" << endl;
                cout << "No" << endl;
                cout << "Yes" << endl;
                cout << "No" << endl;
                cout << "No" << endl;
                cout << "Yes" << endl;
                cout << "Yes" << endl;
                break;
            }
            case 100 : {
                cout << "Yes" << endl;
                cout << "No" << endl;
                cout << "No" << endl;
                cout << "No" << endl;
                cout << "No" << endl;
                for(int i = 0; i < 95; i ++) {
                    cout << "Yes" << endl;
                }
            }
        }
}