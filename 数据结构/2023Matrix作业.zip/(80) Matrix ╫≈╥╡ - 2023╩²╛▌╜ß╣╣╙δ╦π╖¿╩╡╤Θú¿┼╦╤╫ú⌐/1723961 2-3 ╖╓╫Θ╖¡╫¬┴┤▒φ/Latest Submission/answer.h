#include <stdio.h>
#include "ListNode.h"
ListNode* trans(ListNode* head, ListNode* tail);

ListNode* reverseKGroup(ListNode* head, int k) {
    if(head == NULL || head -> next == NULL) {
        return head;
    }
    ListNode * temp = head;
    for(int i = 0; i < k; i ++) {
        if(temp == NULL) {
            return head;
        }
        temp = temp -> next;
    }
    ListNode* new_head = trans(head, temp);
    head -> next = reverseKGroup(temp, k);
    return new_head;
}

ListNode* trans(ListNode* head, ListNode* tail) {
    ListNode* pre = NULL;
    ListNode* net = NULL;
    while(head != tail) {
        net = head -> next;
        head -> next = pre;
        pre = head;
        head = net;
    }
    return pre;
}