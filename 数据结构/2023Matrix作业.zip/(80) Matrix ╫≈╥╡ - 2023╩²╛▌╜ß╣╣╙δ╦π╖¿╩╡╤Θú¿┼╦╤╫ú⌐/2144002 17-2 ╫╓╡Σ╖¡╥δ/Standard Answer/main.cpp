#include<iostream>
#include<map>
#include <string>
#include <cstdio>

using namespace std;

int main()

{
    string str1, str2, str;
    map<string, string> m;
    map<string, string>::iterator it;
    while(1)
    {
        cin>>str1;
        if(getchar()!=' ')
            break;
        cin>>str2;
        m[str2] = str1;
    }
    do
    {
        it = m.find(str1);
        if(it==m.end())
            cout<<"eh"<<endl;
        else
            cout<<m[str1]<<endl;
    }
    while(cin>>str1);
    return 0;
}
