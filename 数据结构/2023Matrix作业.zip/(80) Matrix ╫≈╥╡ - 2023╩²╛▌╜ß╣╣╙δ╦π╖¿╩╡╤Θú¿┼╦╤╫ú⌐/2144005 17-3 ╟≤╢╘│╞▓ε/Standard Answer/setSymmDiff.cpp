#include <iostream>
#include <vector>

using namespace std;


typedef vector<int> set;


set setSymmDiff(const set A, const set B){
  set C;
  unsigned i, j;
  i=j=0;
  while (i < A.size() && j < B.size()) {
     if (A[i] < B[j])
        C.push_back(A[i++]);
     else if (B[j] < A[i])
        C.push_back(B[j++]);
     else {
        i++; j++;
     }
  }
  while (i < A.size())
     C.push_back(A[i++]);
  while (j<B.size())
    C.push_back(B[j++]);

  return C;
}



void print(set a){
  //cout << s <<endl;
  vector<int> :: const_iterator it = a.begin();
  while (it!=a.end()){
 // for (unsigned i = 0; i< a.size(); i++) 
   cout << *it << " ";
   it++;
  }
  cout << endl;
}
void print(set a, set b, set c){

//  print(a, "Set A:");
//  print(b, "Set B:");
//  cout << "The symmetric difference: " << endl;
//  print(c, "The Symmetric Difference:");
}


int main(){
   vector<int> A, B,C;
   int N,m,n;
   cin >> N;
   while (N--){
     cin >> m;
     A.resize(m);
     for (int i=0; i < m; i++){
        cin >> A[i];
     }
     cin >> n;
    B.resize(n);
     for (int i=0; i < n; i++){
        cin >> B[i];
     }
    C = setSymmDiff(A,B);
  //  print(A,B,C);
    print(C);
     
  } 

   
   return 0;
}
