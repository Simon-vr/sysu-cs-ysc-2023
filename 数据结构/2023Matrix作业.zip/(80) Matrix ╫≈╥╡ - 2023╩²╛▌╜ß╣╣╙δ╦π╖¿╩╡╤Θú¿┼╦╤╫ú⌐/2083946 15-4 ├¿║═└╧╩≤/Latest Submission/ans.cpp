#include <iostream>
using namespace std;

int main(void) {
    int a[4];
    for(int i = 0; i < 4; i ++) {
        cin >> a[i];
    }
    if(a[0] == 4 || (a[0] == 1 && a[3] == 3)) {
        cout << "false" << endl;
    } else {
        cout << "true" << endl;
    }
    return 0;
}