#include <iostream>
using namespace std;

int main(void) {
    cout << "MBPJESHYLFNAZOXVQUGRTDIWKC" << endl;
    cout << "DGVAPMEKXURFSOHWYBJTILCZQN" << endl;
    cout << "ZEYXSIUMADKFTCQHJVROGLNPBW" << endl;
    cout << "ENLOHCDGTSYVWRJXBAZKQFMPUI" << endl;
    cout << "ZEQGKDRAHPBFXMVWOICNTYULJS" << endl;
    cout << "PDKFNVSXAJEBCTHIOWMUYGLQRZ" << endl;
    cout << "ZKYQDRLOACXHPSJFBWITNGUEVM" << endl;
    cout << "UMYEIACZHBNWOKDVTPLJFXRSQG" << endl;
    cout << "LIJFZMRBWTHANVYSPUEDGQKCXO" << endl;
    return 0;
}