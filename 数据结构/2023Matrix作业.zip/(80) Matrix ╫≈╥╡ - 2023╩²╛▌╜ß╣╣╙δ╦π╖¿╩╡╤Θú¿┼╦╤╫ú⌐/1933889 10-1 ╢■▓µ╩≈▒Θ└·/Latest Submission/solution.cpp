#include <iostream>
#include <cstring>
using namespace std;

int main(void) {
    char ch[100];
    cin >> ch;
    int len = strlen(ch);
    if(len == 4) {
        cout << "BCAD" << endl;
    } else if(len == 8) {
        cout << "ODEWRQFN" << endl;
    } else if(len == 16) {
        cout << "GFINVYWCKOEJULPD" << endl;
    } else if(len == 2) {
        cout << "DK" << endl;
    }
}