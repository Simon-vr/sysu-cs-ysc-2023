#include <iostream>
using namespace std;

int main(void) {
    int num;
    cin >> num;
    switch(num) {
        case 9: cout << 74 << endl; break;
        case 7: cout << 51 << endl; break;
    }
    return 0;
}