#include "graph.h"
int main()
{
    // 1:"   "intro
    // 3:n"  ","   ","   "short
    // 2:"  ","   "all
    std::string map="D:\\data_struct\\A3\\Basic\\Tests\\campus.txt";
    std::string request="D:\\data_struct\\A3\\Basic\\Tests\\requests.txt";
    std::string answer="D:\\data_struct\\A3\\Basic\\Tests\\answers.txt";
    
    std::cout << "map:";
    std::cin >> map;
    std::cout << "request:";
    std::cin >> request;
    std::cout << "answer:";
    std::cin >> answer;
    
    
    graph campus(map);
    auto questions = get_request(request);

    std::ofstream ans(answer);
    if (ans.is_open())
    {
        int count=0;
        for (auto i : questions)
        {
            count++;
            ans<<"\n"<<"request "<<count<<"\n";
            if (i.lable == 1)
            {
                auto str = campus.get_info(i.require[0]);
                ans<<str;
            }
            else if (i.lable == 3)
            {
                auto path = campus.shortist_path(i.require);
                for(int i=0;i<path.size();i++)
                {
                    ans<<path[i];
                    if(i!=path.size()-1)
                        ans<<"->";
                }
                ans<<"\n";
                ans<<"distance:"<<campus.get_len(path)<<"m  ";
                ans<<"mean_degree:"<<campus.get_mean(path);
            }
            else if (i.lable == 2)
            {
                auto path = campus.all_path(i.require[0],i.require[1]);
                for(int j=0;j<path.size();j++)
                {
                    for(int i=0;i<path[j].size();i++)
                    {
                        ans<<path[j][i];
                        if(i!=path[j].size()-1)
                            ans<<"->";
                    }
                    ans<<"\n";
                }
            }
        }
    }
    else std::cout << "wrong" << std::endl;
}