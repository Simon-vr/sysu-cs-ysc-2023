#include "graph.h"
struct find_ver_name
{
    std::string target;
    find_ver_name(std::string name):target(name){}
    bool operator()(vertex a)
    {
        return a.name == target;
    }
};

vertex graph::get_vertex(std::string name)
{
    auto it = std::find_if(ver.begin(), ver.end(),find_ver_name(name));
    if(it!=ver.end())
        return *it;
    std::cout<<"get_vertex notfound"<<std::endl;
    return vertex();
}

edge graph::get_edge(int key)
{
    if(key<edg.size())
        return edg[key];
    //std::cout<<"get_edge notfound"<<std::endl;
    return edge();
}

void graph::dfs(std::vector<std::vector<int>>& res, std::vector<int>& path,
                int from, int cur, int to)
{
    if(cur == to)
    {
        path.push_back(cur);
        res.push_back(path);
        path.pop_back();
        return;
    }
    path.push_back(cur);
    for(int i=0; i<ver.size(); i++)
    {
        if(matrix[cur][i] != -1)
        {
            if(i == from || i == cur)
                continue;
            if(std::find(path.begin(), path.end(), i) != path.end())
                continue;
            dfs(res,path,cur,i,to);
        }
    }
    path.pop_back();
}

std::vector<int> graph::dijkstra(int start, int end)
{
    if(start == end)
        return std::vector<int>();
        std::vector<int> bridges(ver.size(),-1);
        std::vector<int> previous(ver.size(), -1);
        std::vector<bool> sites(ver.size(),false);
        previous[start] = start;
        bridges[start] = 0;
        int cur=start;


        while(cur!=end)
        {
            sites[cur] = true;//维护site
            for(int i=0;i<ver.size();i++)//维护bridge
            {
                if(matrix[cur][i] != -1 && sites[i] == false)
                {
                    if(bridges[i]==-1 || bridges[cur]+get_edge(matrix[cur][i]).len < bridges[i])
                    {
                        bridges[i]=bridges[cur]+get_edge(matrix[cur][i]).len;
                        previous[i] = cur;//维护previous
                    }
                }
            }

            //寻找新的cur
            int minium=INT_MAX;
            cur=0;
            for(int i=0; i<ver.size(); i++)
            {
                if(bridges[i]!=-1 && sites[i]==false && bridges[i]<=minium)
                {
                    minium=bridges[i];
                    cur=i;
                }
            }
            if(minium == INT_MAX)
                return std::vector<int>();
        }
        std::vector<int> path;
        int j=end;
        while(j!=start)
        {
            path.insert(path.begin(),j);
            j = previous[j];
        }
        return path;
}

graph::graph(std::string map_name)
{
    std::ifstream campus(map_name);
    if(campus.is_open())
    {
        std::string line;
        while(std::getline(campus,line)&&line!="EDGE")
        {
            int key=0;
            std::size_t firstSpace = line.find(' ');
            key = std::stoi(line.substr(0, firstSpace));
            std::string name = line.substr(firstSpace + 1);
            std::string tem;
            std::string info;
            while(std::getline(campus,tem)&&tem!="")
                info.append(tem);
            ver.push_back(vertex(key,name,info));
        }
        int lable=0;
        matrix.resize(ver.size(), std::vector<int>(ver.size(),-1));
        while(std::getline(campus,line)&&line!="END")
        {
            int v1,v2,w1,w2;
            std::istringstream num(line);
            num>>v1>>v2>>w1>>w2;
            edg.push_back(edge(lable,v1,v2,w1,w2));
            matrix[v1][v2]=lable;
            matrix[v2][v1]=lable;
            lable++;
        }
    }
    else
        std::cout<<"open .txt wrong"<<std::endl;
    campus.close();
}

std::vector<std::vector<int>> graph::all_path(std::string from, std::string to)
{
    int f = get_vertex(from).key;
    int t = get_vertex(to).key;
    std::vector<int> path;
    std::vector<std::vector<int>> res;
    dfs(res,path,-1,f,t);
    return res;
    /*
    if(res.size() == 0)
        return std::vector<std::string>();
    std::vector<std::string> sum_path;
    for(int i=0;i<res.size();i++)
    {
        std::string tem;
        for(int j=0;j<res[i].size();j++)
        {
            tem.append(std::to_string(res[i][j]));
            if(j!=res[i].size()-1)
                tem.append("->");
        }
        sum_path.push_back(tem);
    }
    return sum_path;
    */
}

std::vector<int> graph::shortist_path(std::vector<std::string> sites)
{
    std::vector<int> res;
    for(int i=0;i<sites.size()-1;i++)
    {
        int start = get_vertex(sites[i]).key;
        int end = get_vertex(sites[i+1]).key;
        auto tem = dijkstra(start,end);
        if(i==0)
            res.push_back(start);
        for(int i:tem)
            res.push_back(i);
    }
    return res;
}


int graph::get_len(std::vector<int> path)
{
    int sum=0;
    for(int i=0;i<path.size();i++)
    {
        if(i+1 < path.size())
            sum+=get_edge(matrix[path[i]][path[i+1]]).len;
    }
    return sum;
}

int graph::get_mean(std::vector<int> path)
{
    int sum=0;
    int count=0;
    for(int i=0;i<path.size();i++)
    {
        if(i+1 < path.size())
        {
            sum+=get_edge(matrix[path[i]][path[i+1]]).w;
            count++;
        }
    }
    if(count!=0)
        return sum/count;
    return 0;
}

std::string graph::get_info(std::string name)
{
    auto it = std::find_if(ver.begin(), ver.end(),find_ver_name(name));
    if(it!=ver.end())
        return it->info;
    else
        return "get_info notfound";
}

std::vector<ques> get_request(std::string filename)
{
    std::ifstream request(filename);
    if(request.is_open())
    {
        std::vector<ques> res;
        std::string line;
        while(std::getline(request,line)&&line!="END")
        {
            std::istringstream num(line);
            int lable;
            num>>lable;
            ques tem;
            if(lable == 1)
            {
                std::string name;
                num>>name;
                tem.lable=1;
                tem.require.push_back(name);
            }
            else if(lable == 2)
            {
                std::string name1;
                std::string name2;
                num>>name1;
                num>>name2;
                tem.lable=2;
                tem.require.push_back(name1);
                tem.require.push_back(name2);
            }
            else
            {
                tem.lable = lable;
                int n;
                num>>n;
                std::string name;
                while(n--)
                {
                    num>>name;
                    tem.require.push_back(name);
                }
            }
            res.push_back(tem);
        }
        return res;
    }
    std::cout<<"request notfound"<<std::endl;
    return std::vector<ques>();
}
