#pragma once

#include <iostream>
#include <fstream>
#include <sstream>
#include <climits>
#include <algorithm>
#include <vector>
#include <string>
struct vertex
{
    int key;
    std::string name;
    std::string info;
    vertex(int a, std::string b, std::string c) : key(a), name(b), info(c) {}
    vertex() = default;
};
struct edge
{
    int key;
    std::string name;
    int len;
    int w;
    int v1;
    int v2;
    edge(int a, int v1, int v2, int w1, int w2) : key(a), v1(v1), v2(v2), len(w1), w(w2) {}
    edge() : v1(-2), v2(-2) {}
};
struct ques
{
    int lable;
    std::vector<std::string> require;
};
std::vector<ques> get_request(std::string filename);
class graph
{
private:
    std::vector<vertex> ver;
    std::vector<edge> edg;
    std::vector<std::vector<int>> matrix;
    vertex get_vertex(std::string name);
    edge get_edge(int key);
    void dfs(std::vector<std::vector<int>> &res, std::vector<int> &path, int from, int cur, int to);
    std::vector<int> dijkstra(int start, int end);

public:
    graph(std::string campus);
    std::vector<std::vector<int>> all_path(std::string from, std::string to);
    std::vector<int> shortist_path(std::vector<std::string> sites);
    int get_len(std::vector<int> path);
    int get_mean(std::vector<int> path);
    std::string get_info(std::string name);
};
