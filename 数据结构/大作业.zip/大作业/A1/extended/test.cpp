#include <iostream>
#include <vector>
#include<climits>
using namespace std;
struct node
{
    int val;
    int le;
    int ri;
    node(int a, int b, int c) : val(a), le(b), ri(c) {}
};
class heap
{
private:
    vector<node> tree;

public:
    heap()
    {
        tree.push_back(node(INT_MAX, 0, 0));
    }
    int top(){return tree[1].val;}
    int get()
    {
        int res = tree[1].val;
        tree[1].val = tree[tree.size()-1].val;
        tree.pop_back();
        adjust_down(1);
        return res;
    }
    void push(int x)
    {
        auto tem = node(x, 0, 0);
        tree.push_back(tem);
        adjust_up(tree.size() - 1);
    }
    void adjust_up(int t)
    {
        if (t == 1)
            return;
        int l, f;

        l = t;
        f = t / 2;
        if (tree[l].val < tree[f].val)
        {
            int tem = tree[f].val;
            tree[f].val = tree[l].val;
            tree[l].val = tem;
            adjust_up(f);
        }
        return;
    }
    void adjust_down(int t)
    {
        if (tree[t].le == 0 && tree[t].ri == 0)
            return;
        int l = tree[t].le;
        int r = tree[t].ri;
        if (tree[l].val <= tree[r].val && tree[l].val < tree[t].val)
        {
            int tem = tree[t].val;
            tree[t].val = tree[l].val;
            tree[l].val = tem;
            adjust_down(l);
        }
        else if (tree[l].val >= tree[r].val&&tree[r].val < tree[t].val)
        {
            int tem = tree[t].val;
            tree[t].val = tree[r].val;
            tree[r].val = tem;
            adjust_down(r);
        }
        return;
    }
};
int main()
{
    int n;
    cin >> n;
    heap ann;
    while (n--)
    {
        int op;
        cin >> op;
        if (op == 1)
        {
            int x;
            cin >> x;
            ann.push(x);
        }
        else if (op == 2)
        {
            cout<<ann.top()<<endl;
        }
        else if (op == 3)
        {
            ann.get();
        }
    }
}