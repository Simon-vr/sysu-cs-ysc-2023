#pragma once
#include<iostream>
#include<string>
#include<cmath>
#include<stack>
bool valid(std::string s);
double compute(std::string s);
double isnumber(std::string s, int start, int& restart);
char isoperator(std::string s, int start, int& restart);
bool compare(char a, char b);//true:a>b, false:a<b
bool check_brackets(std::string s);  
void count_brackets_sub(std::string s, int start, int& restart);
double compute_brackets(std::string s, int start, int& restart);
double operate(double a, double b, char c);