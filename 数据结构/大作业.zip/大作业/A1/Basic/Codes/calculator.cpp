#include "calculator.h"
using namespace std;
char arr[5] = { '+','-','*','/','^' };

bool valid(std::string s)
{
    /*
    1.������ţ�
    2.����Ƿ���������ţ������ֺͲ������Ϳո��⣩
    3.�������������ݵ�˳���Ƿ����
        �������ܳ������������ķ��ţ��������ŵ������
            ���ܳ������������������м��ǿո�
    */
    if (!check_brackets(s))
    {
        cout << "error:���Ų�ƥ��" << endl;
        return false;
    }

    int tem = 0;  //0:����ν�� 1��ǰһ�������֣� 2��ǰһ���ǲ�����, 3:ǰһ���Ǻ����ţ� 4��ǰһ����ǰ����
    for (int i = 0; i < s.length();)
    {
        if (s[i] == ' ')
        {
            i++;
            continue;
        }
        int restart = i;
        if (isnumber(s, i, restart) == -1 && isoperator(s, i, restart) == ' ')//��������ַ�
        {
            cout << "error:���������ַ�" << endl;
            return false;
        }
        else if (isnumber(s, i, restart) != -1)//�������
        {
            if (tem == 1)
            {
                cout << "error:������������" << endl;
                return false;
            }
            else if (tem == 3)
            {
                cout << "error:�����Ų�����������" << endl;
                return false;
            }
            else
            {
                tem = 1;
                i = restart;
            }
        }
        else//��������
        {
            if (isoperator(s, i, restart) == '(')
            {
                if (tem == 1)
                {
                    cout << "error:���ֺ�������ǰ����"<<endl;
                    return false;
                }
                tem = 4;
                i = restart;
            }
            else if (isoperator(s, i, restart) == ')')
            {
                if (tem == 2)
                {
                    cout << "error:�������������Ӻ�����" << endl;
                    return false;
                }
                else if (tem == 4)
                {
                    cout << "error:���ֿ�����" << endl;
                    return false;
                }
                else
                {
                    tem = 3;
                    i = restart;
                }
            }
            else
            {
                if (tem == 2)
                {
                    cout << "error:��������������" << endl;
                    return false;
                }
                else if (tem == 4 && s[i] != '-' && s[i] != '+')
                {
                    cout << "error:����Ŀ�����" << endl;
                    return false;
                }
                else if (i == s.length() - 1)
                {
                    cout << "error:����ĩλ������" << endl;
                    return false;
                }
                else
                {
                    tem = 2;
                    i = restart;
                }
            }
        }
    }
    return true;
}

double compute(std::string s)
{
    stack<double> num;
    stack<char> ope;
    bool begin = true;
    for (int i = 0; i < s.length();)
    {
        if (s[i] == ' ')
        {
            i++;
            continue;
        }
        /*
        1. ������� �� �ַ�
        2. ���֣�ѹջ�� ���ţ�
        3. ���ţ�ѹջ �� ���� �� ���� �� ��Ŀ
        */
        int restart = i;
        double cur_num = isnumber(s, i, restart);
        if (cur_num != -1)
        {
            i = restart;
            num.push(cur_num);
            begin = false;
            continue;
        }

        char cur_ope = isoperator(s, i, restart);
        if (begin == true && cur_ope != '(')//��Ŀ����,i==0�����⣬���ǿո�
        {
            num.push(0);
            ope.push(s[i]);
            i = restart;
        }
        else if (cur_ope == '(')//��������
        {
            num.push(compute_brackets(s, i, restart));
            i = restart;
        }
        else if (ope.empty() || compare(ope.top(), cur_ope) == false)//ѹջ
        {
            ope.push(cur_ope);
            i = restart;
        }
        else//����
        {
            if (num.size() < 2)
            {
                cout << "compute error" << endl;
                return 0;
            }

            double b = num.top();
            num.pop();
            double a = num.top();
            num.pop();
            char c = ope.top();
            ope.pop();
            num.push(operate(a, b, c));
            ope.push(cur_ope);
            i = restart;
        }
        begin = false;
    }
    if (num.empty())
    {
        cout << "compute error" << endl;
        return 0;
    }
    if (num.size() == 1)
        return num.top();
    while (!ope.empty())
    {
        double b = num.top();
        num.pop();
        double a = num.top();
        num.pop();
        char c = ope.top();
        ope.pop();
        num.push(operate(a, b, c));
    }
    if (num.size() == 1 && ope.empty())
        return num.top();
    else
        cout << "compute error" << endl;
}

double isnumber(std::string s, int start, int& restart)
{
    if (s[start] < '0' || s[start]>'9')
    {
        restart = start;
        return -1;
    }
    stack<int> num;
    bool dot = false;
    int bigger_one = 0;
    int i = 0;
    for (i = start; i < s.length(); i++)
    {
        if (s[i] != '.' && (s[i] < '0' || s[i]>'9'))
        {
            break;
        }
        else if (s[i] == '.')
        {
            bigger_one = num.size();
            num.push(-1);
            dot = true;
        }
        else
            num.push(s[i] - 48);
    }

    double res = 0;
    if (dot == false)
    {
        int bit = 0;
        while (!num.empty())
        {
            res += num.top() * pow(10, bit);
            num.pop();
            bit++;
        }
    }
    else
    {
        int bit = -(num.size() - 1 - bigger_one);
        while (!num.empty())
        {
            if (num.top() == -1)
                num.pop();
            res += num.top() * pow(10, bit);
            num.pop();
            bit++;
        }
    }
    restart = i;
    return res;
}

char isoperator(std::string s, int start, int& restart)
{
    if (s[start] == '(' || s[start] == ')')
    {
        restart = start + 1;
        return s[start];
    }
    for (int i = 0; i < 5; i++)
    {
        if (arr[i] == s[start])
        {
            restart = start + 1;
            return s[start];
        }
    }
    restart = start;
    return ' ';
}

bool compare(char a, char b)
{
    //true:a>b, false:a<b
    if (a == b)
        return true;
    if ((a == '+' || a == '-') && (b == '+' || b == '-'))
        return true;
    if ((a == '*' || a == '/') && (b == '*' || b == '/'))
        return true;
    for (int i = 0; i < 5; i++)
    {
        if (arr[i] == b)
            return true;
        if (arr[i] == a)
            return false;
    }
    return true;
}

bool check_brackets(std::string s)
{
    stack<char> bracks;
    for (int i = 0; i < s.length(); i++)
    {
        if (s[i] == '(')
            bracks.push(i);
        else if (s[i] == ')')
        {
            if (bracks.empty())
                return false;
            bracks.pop();
        }
    }
    if (!bracks.empty())
        return false;
    return true;
}

void count_brackets_sub(std::string s, int start, int& restart)
{
    stack<int> bracks;
    for (int i = start; i < s.length(); i++)
    {
        if (s[i] == '(')
            bracks.push(i);
        else if (s[i] == ')')
        {
            bracks.pop();
            if (bracks.empty())
            {
                restart = i + 1;
                return;
            }
        }
    }
    return;
}

double compute_brackets(std::string s, int start, int& restart)
{
    count_brackets_sub(s, start, restart);
    string brack = s.substr(start + 1, restart - start - 2);
    return compute(brack);
}

double operate(double a, double b, char c)
{
    switch (c)
    {
        case '+':
            return a + b;
        case '-':
            return a - b;
        case '*':
            return a * b;
        case '/':
            if (b == 0)
                cout << "error:����Ϊ0" << endl;
            return a / b;
        case '^':
            return pow(a, b);
        default:
            cout << "operate error" << endl;
            return 0;
    }
}
