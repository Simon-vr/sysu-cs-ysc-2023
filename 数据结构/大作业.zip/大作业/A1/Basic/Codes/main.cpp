﻿#include<iostream>
#include<stdio.h>
#include "calculator.h"
using namespace std;
int main()
{
	cout << "Type how many rounds of calculations are required" << endl;
	int n;
	cin >> n;
	cout << "Welcome to the calculator, press 'q' to exit" << endl;
	while (n--)
	{
		string s;
		char t;
		getline(cin, s);
		if (s == "q")
			break;
		if (s == "")
			continue;
		if(valid(s))
			cout << compute(s) << endl;
		cout << "--------------------------------------------" << endl;
	}
	cout << "calculator was closed" << endl;
}