# 功能说明

### 基本要求实现：

- 建树：从数据集文件`data_freq.txt`中统计字符出现的频度，建立Huffman树，存储在codemap.txt中

- 编码：对源文件`data_source.txt`中的正文进行编码，然后将结果存入文件`encode.txt`中。

- 译码：对编码文件`encode`中的代码进行译码，结果存入文件`decode.txt`中。

- 打印：将Huffman树以凹入表示法写入文件`Hufftree.txt`中。

### 选作内容实现

- 从源文件`data_source.txt`中统计频率，然后将Huffman树存储在`data_encoded`文件中，使得译码时不需要`codemap`文件。

- 实现对任意字符集的编码（压缩）和译码（解压缩），而不仅仅是文本文件。

- 将你实现的算法，与其他工业压缩软件（如WinRAR、7-Zip）进行性能对比。（见报告）


