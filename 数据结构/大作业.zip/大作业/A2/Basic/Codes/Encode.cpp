#include "Encode.h"

std::map<char, int> FreqMapBuild(const std::string filename)
{
    std::map<char, int> freqmap;
    //以二进制方式读取文件
    std::ifstream srcfile(filename,std::ios::in|std::ios::binary);
    if(srcfile.is_open())
    {
        char ch;//一次读取一字节
        while(srcfile.read(&ch,1))//统计字节出现频数
        {
            if(freqmap.find(ch)!=freqmap.end())
                freqmap[ch]++;
            else
                freqmap[ch]=1;
        }
    }
    else//报错
        std::cout<<"FreqMapBuild_error:cannot find or read source file"<<std::endl;
    /*检查统计结果
    for(auto it = freqmap.begin(); it!=freqmap.end();it++)
        std::cout<<it->first<<' '<<it->second<<std::endl;
    */
    return freqmap;
}

BTree TreeBuild(std::map<char, int> freqmap)
{
    //将map以vec的方式存储，构建huffman树直到vector中只有一个元素
    std::vector<node*> huffvec;//初始化
    for(auto it=freqmap.begin(); it!=freqmap.end();it++)
    {
        node* tem = new node(*it);
        huffvec.push_back(tem);
    }
    while(huffvec.size()!=1)
    {//统计最小项与次小项
        int argmin_1;
        int argmin_2;
        if(huffvec[0]->w.second < huffvec[1]->w.second)
        {
            argmin_1 = 0;
            argmin_2 = 1;
        }
        else
        {
            argmin_1 = 1;
            argmin_2 = 0;
        }
        for(int i=2;i<huffvec.size();i++)
        {
            //注意：比较的是频数
            if(huffvec[i]->w.second < huffvec[argmin_1]->w.second)
            {
                argmin_2 = argmin_1;
                argmin_1 = i;
            }
            else if(huffvec[i]->w.second < huffvec[argmin_2]->w.second)
                argmin_2 = i;
        }
        //合并最小项与次小项
        int sum_freq = huffvec[argmin_1]->w.second + huffvec[argmin_2]->w.second;
        char sum_leaf = '+';
        std::pair<char,int> head_w(sum_leaf,sum_freq);
        node* head = new node(head_w, huffvec[argmin_1], huffvec[argmin_2]);
        huffvec.erase(huffvec.begin()+argmin_1);

        //删除时的细节处理
        if(argmin_1>argmin_2)
            huffvec.erase(huffvec.begin()+argmin_2);
        else
            huffvec.erase(huffvec.begin()+argmin_2-1);

        huffvec.push_back(head);
        
        /*检查代码
        std::cout<<head->left->w.first<<" "<<head->right->w.first<<std::endl;
        for(auto it=huffvec.begin(); it!=huffvec.end(); it++)
            std::cout<<(*it)->w.first<<'-'<<(*it)->w.second<<"     ";
        std::cout<<std::endl;
        */
    }
    
    BTree hufftree(huffvec[0]);
    /*检查代码
    auto p = hufftree.print();
    for(auto i : p)
    {
        int block = i.second;
        node* key = i.first;
        while(block--)
            std::cout<<' ';
        std::cout<<key->w.first<<' '<<key->w.second<<std::endl;
    }
    */
    return hufftree;
}

void string_maker(std::map<char, std::string>& codemap, std::string& cur, node* key)
{
    if(key == nullptr)
        return;
    if(key->left == nullptr && key->right == nullptr)
    {
        codemap[key->w.first] = cur;
        return;
    }

    //规定：左子树添0，右子树填1
    cur.append("0");
    string_maker(codemap,cur,key->left);
    cur.pop_back();
    cur.append("1");
    string_maker(codemap,cur,key->right);
    cur.pop_back();
}

std::map<char, std::string> CodeMapBuild(BTree hufftree, std::string filename)
{
    node* head = hufftree.get_head();
    std::map<char, std::string> codemap;
    //遍历填充codemap
    std::string head_begin = "0";
    string_maker(codemap,head_begin,head);
    //写入文件
    std::ofstream target(filename);
    if (target.is_open()) 
    {
        for (const auto& pair : codemap) 
            target << pair.first << pair.second << "\n"; // 格式为 char  string
        //codemap部分结束的标志
        target<<"END\n";
        target.close();
    } 
    else 
        std::cout<<"CodeMapBuild_error:cannot write source file"<<std::endl;
    target.close();
    return codemap;
}

void Encode(std::map<char, std::string> codemap, std::string srcname, std::string enname)
{
    //如果enname文件不存在，则创建文件
    std::ifstream infile(enname);
    if(!infile)
    {
        std::ofstream outfile(enname);
        outfile.close();
    }
    infile.close();

    //enname文件已存在，追加编码内容
    std::ofstream target(enname,std::ios::binary | std::ios::app);
    std::ifstream source(srcname,std::ios::binary);
    //即将写入编码文件的位，用vec存储
    std::vector<char> arr;
    //转录源文件
    if(source.is_open())
    {
        char ch;//一次读取一字节
        while(source.read(&ch,1))
        {
            //这里，有个问题很重要！！一次写入的是一字节，需要把字节转换成位
            auto it = codemap.find(ch);
            if(it!=codemap.end())
            {
                for(char ele : it->second)
                    arr.push_back(ele);
            }
            else
                std::cout<<"Encode_error:can't found a char"<<std::endl;
        }
    }
    else
        std::cout<<"Encode_error:read source went wrong"<<std::endl;
    //写入目标文件
    if(target.is_open())
    {
        //encode部分开始的标志
        target<<"BEG\n";
        for(int i=0;i<arr.size();i+=8)
        {
            if(i==0 && i+8 >= arr.size())//未满8位的处理：000xxxxx,最后写入前面补0的个数
            {
                int lenth = arr.size()-i;
                char a=0;
                int weight=1;
                for(int j=arr.size()-1;j>=i;j--)
                {
                    a += (arr[j]-'0')*weight;
                    weight*=2;
                }
                target<<a;
                //测试std::cout<<int(a)<<" ";
                target<<8-lenth;
            }
            else if(i==0)
                continue;
            else
            {
                char a=0;
                int weight=1;
                for(int j=i-1;j>=i-8;j--)
                {
                    a += (arr[j]-'0')*weight;
                    weight*=2;
                }
                target<<a;
                //std::cout<<int(a)<<" ";测试
                if(i+8 >= arr.size())
                {
                    int lenth = arr.size()-i;
                    char a=0;
                    int weight=1;
                    for(int j=arr.size()-1;j>=i;j--)
                    {
                        a += (arr[j]-'0')*weight;
                        weight*=2;
                    }
                    target<<a;
                    //测试std::cout<<int(a)<<" ";
                    target<<8-lenth;
                }
            }
            
        }
    }
    else
        std::cout<<"Encode_error:write target went wrong"<<std::endl;
    target.close();
    source.close();
}

void TreePrint(BTree hufftree,std::string filename)
{
    std::vector<std::pair<node*, int>> printer = hufftree.print();
    std::ofstream target(filename);
    if(target.is_open())
    {
        for(auto i : printer)
        {
            int block = i.second;
            node* key = i.first;
            while(block--)
                target<<' ';
            if(key->left == nullptr && key->right == nullptr)
            {
                target << std::setw(2) << std::setfill('0') << std::hex << static_cast<int>(static_cast<unsigned char>(key->w.first));
                target << std::resetiosflags(std::ios::basefield); 
                target << std::resetiosflags(std::ios::adjustfield);
                target<<' '<<key->w.second<<'\n';
            }
            else
            {
                target << std::resetiosflags(std::ios::basefield); 
                target << std::resetiosflags(std::ios::adjustfield);
                target<<key->w.first<<' '<<key->w.second<<'\n';
            }
        }
    }
    else
        std::cout<<"TreePrint_error:cannot write huffman tree"<<std::endl;
    target.close();
}
