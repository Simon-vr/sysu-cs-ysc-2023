#include<iostream>
#include<map>
#include<vector>
#include<string>
#include<fstream>
#include <iomanip> 
#include "BinaryTree.cpp"
//txt->freqmap->hufftree->codemap

//从data_freq.txt中统计字符出现的频率建立map
std::map<char,int> FreqMapBuild(const std::string filename);
//从freqmap中建立hufftree，节点为pair<char,int>,链式存储于内存中
BTree TreeBuild(std::map<char,int> freqmap);
//从hufftree建立编码对照表<unsigned char,string>，存入encode.txt并在内存保留一份方便encode
std::map<char,std::string> CodeMapBuild(BTree hufftree, std::string filename);
//encode file:  data_source.txt->data_encoded.txt
void Encode(std::map<char,std::string> codemap, std::string srcname, std::string enname);
//将Hufftree以凹入表示法写入文件hfm_tree_print.txt中
void TreePrint(BTree hufftree, std::string filename);