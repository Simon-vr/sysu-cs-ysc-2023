#include "Encode.h"
#include "Decode.h"
#include<iostream>
int main()
{
    std::cout<<"compress[y/n]:";
    char key;
    std::cin>>key;
    if(key == 'y')//encode
    {
        //分离采样
        BTree huffmantree;
        std::cout<<"Import sampling files[y/n]:";
        std::cin>>key;
        if(key == 'y')
        {
            std::cout<<"The file name of the sampling file:";
            std::string freq;
            std::cin>>freq;
            huffmantree = TreeBuild(FreqMapBuild(freq));
        }
        
        //一般采样
        std::cout<<"The file name of the file to be compressed:";
        std::string ori;
        std::cin>>ori;
        std::cout<<"The compressed file name:";
        std::string encode;
        std::cin>>encode;
        if(key == 'n')
            huffmantree = TreeBuild(FreqMapBuild(ori));
        
        //打印编码
        std::map<char,std::string> codemap;
        std::cout<<"Print the codemap separately[y/n]:";
        std::cin>>key;
        if(key == 'y')
            codemap = CodeMapBuild(huffmantree,"codemap.txt");
        else
            codemap = CodeMapBuild(huffmantree,encode);
        
        //压缩
        Encode(codemap,ori,encode);

        //打印树
        std::cout<<"Print the HuffmanTree[y/n]:";
        std::cin>>key;
        if(key == 'y')
            TreePrint(huffmantree,"Hufftree.txt");
    }


    //decode
    std::cout<<"decompress[y/n]:";
    std::cin>>key;
    if(key == 'y')
    {
        //基本信息
        std::cout<<"The file name of the file to be decompressed:";
        std::string encode;
        std::cin>>encode;
        std::cout<<"The file name for the unzipped file:";
        std::string decode;
        std::cin>>decode;

        //提取编码表
        std::map<std::string,char> mapcode; 
        std::cout<<"Whether to use separate codemap[y/n]:";
        std::cin>>key;
        if(key == 'y')
        {
            std::cout<<"The file name of the codemap:";
            std::string codetxt;
            std::cin>>codetxt;
            mapcode = CodeMapExt(codetxt);
        }
        else
            mapcode = CodeMapExt(encode);
        
        //解压
        Decode(encode,decode,mapcode);
    }
}
