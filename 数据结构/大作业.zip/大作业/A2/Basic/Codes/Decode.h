#include<iostream>
#include<map>
#include <bitset>
#include<string>
#include<vector>
#include<fstream>
//encodetxt->codemap & context->decode

//提取编码对照表encode.txt->codemap
std::map<std::string,char> CodeMapExt(std::string filename);
//译码并写入
void Decode(std::string enname,std::string dename,std::map<std::string,char> codemap);
