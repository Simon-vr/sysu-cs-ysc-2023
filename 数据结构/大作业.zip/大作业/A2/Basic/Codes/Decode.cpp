#include "Decode.h"
std::map<std::string,char> CodeMapExt(std::string filename)
{
    std::map<std::string,char> codemap;
    std::ifstream encode(filename);
    if(encode.is_open())
    {
        char ch;
        std::string code;
        std::string line;
        while(encode.read(&ch,1))
        {
            std::getline(encode,line);
            if(ch == 'E' && line == "ND")
                break;
            std::pair<std::string,char> ele(line,ch);
            codemap.insert(ele);
        }
    }
    else
        std::cout<<"CodeMapExt_error:can not find encode file"<<std::endl;
    encode.close();
    /*测试代码
    for(auto i:codemap)
        std::cout<<i.first<<' '<<i.second<<std::endl;
    */
    return codemap;
}

void Decode(std::string enname, std::string dename, std::map<std::string,char> codemap)
{
    std::ofstream decode(dename,std::ios::out | std::ios::binary);
    std::ifstream encode(enname,std::ios::in | std::ios::binary);
    //把读指针移动到规定的位置
    std::string arr;
    if(encode.is_open())
    {
        std::string line;
        bool flag=false;
        while(std::getline(encode,line))
        {
            if(line == "BEG")
                break;       
        }
        // 获取文件大小
        std::streampos ori = encode.tellg();
        encode.seekg(0, std::ios::end);  
        std::streampos file_size = encode.tellg();  
        encode.seekg(ori);
        char byte;
        while(encode.read(&byte,1))
        {
            if(static_cast<std::streamoff>(encode.tellg())>static_cast<std::streamoff>(file_size)-2)
            {
                char tem = byte;
                std::string tem_bit;
                std::bitset<8> bits(tem);
                for (int i=7; i >= 0; i--)
                    tem_bit.push_back(bits[i]?'1':'0');
                encode.read(&byte,1);
                int num = byte-'0';
                for(int i=num;i<8;i++)
                    arr.push_back(tem_bit[i]);
                break;
            }
            std::bitset<8> bits(byte);
            for (int i=7; i>=0; i--)
                arr.push_back(bits[i]?'1':'0');
        }
    }
    else
        std::cout<<"Decode_error:can not find encode file"<<std::endl;
    /*test code
    for(auto i:arr)
        std::cout<<i;
    */
    int limit=100;
    for(auto i:codemap)
        limit = i.first.length()>limit? i.first.length():limit;
    if(decode.is_open())
    {
        int start=0;
        for(int i=1;i<=arr.length();i++)
        {
            if(codemap.find(arr.substr(start,i-start)) != codemap.end())
            {
                auto key = codemap.find(arr.substr(start,i-start));
                decode<<key->second;
                start = i;
            }
            else if(i-start > limit)
            {
                std::cout<<"Decode_error:can not find correspond char"<<std::endl;
                break;
            }
        }
    }
    else
        std::cout<<"Decode_error:can not find decode file"<<std::endl;
}
