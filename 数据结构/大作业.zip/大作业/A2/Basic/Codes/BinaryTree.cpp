#include<utility>
#include<vector>
struct node
{
    std::pair<char, int> w;
    node* left;
    node* right;
    node(std::pair<char,int> a,node* b=nullptr, node* c = nullptr):w(a),left(b),right(c){}
    node() =default;
};

class BTree
{
    private:
    node* head;
    //方便凸入表示, <node*,int>表示内容和凸入空格数
    std::vector<std::pair<node*, int>> show; 
    //所有的叶子节点构成的数组
    std::vector<node*> leaves;

    public:
    //头节点无哨兵，初始化凸入数组
    BTree(node* a):head(a){traverse(a,0);}
    BTree() =default;
    //先序遍历，show,leaves 初始化
    void traverse(node* h,int count)
    {
        if(h == nullptr)
            return;
        if(h->left == nullptr && h->right == nullptr)
            leaves.push_back(h);
        std::pair<node*,int> tem(h,count);
        show.push_back(tem);
        count++;
        traverse(h->left,count);
        traverse(h->right,count);
    }
    std::vector<node*> get_leaves(){return leaves;}
    std::vector<std::pair<node*, int>> print(){return show;}
    node* get_head(){return head;}
};
