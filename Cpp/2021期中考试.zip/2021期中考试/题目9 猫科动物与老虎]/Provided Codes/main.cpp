#include <iostream>
#include "todo.hpp"
using namespace std;

int main(){
    Cat Jerry;
    Tiger Tom(996);
    Tiger Spike(955);
    return 0;
}