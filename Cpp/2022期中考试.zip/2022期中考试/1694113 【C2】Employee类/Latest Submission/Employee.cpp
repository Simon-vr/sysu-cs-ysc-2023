#include <iostream>
#include "Employee.hpp"
using namespace std;

int Employee::numberOfObjects = 0;

Employee::Employee(int id) : id(id) {
    numberOfObjects ++;
}

Employee::~Employee() {
    numberOfObjects --;
}

int Employee::getId() {
    return this -> id;
}
int Employee::getNumberOfObjects() {
    return numberOfObjects;
} 