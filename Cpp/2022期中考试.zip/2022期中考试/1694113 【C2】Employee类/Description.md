# 【C2】Employee类

## 问题描述

根据头文件`Employee.hpp`完善`Employee`类

## 样例输入

```
111
```

## 样例输出

```
number of Employee objects: 1
number of Employee objects: 2
After creating worker1 and worker2
worker1 id: 111
worker2 id: 111
number of Employee objects: 3
number of Employee objects: 2
```

## 提示

静态成员变量

