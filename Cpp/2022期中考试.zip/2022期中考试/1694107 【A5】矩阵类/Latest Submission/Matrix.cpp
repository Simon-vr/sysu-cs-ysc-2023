#include <iostream>
#include "Matrix.hpp"
using namespace std;

Matrix::~Matrix() {
    for(int i = 0; i < this -> row; i ++) {
        delete[] this -> mat[i];
    }
    delete[] this -> mat;
}

Matrix::Matrix(int row,int col) {
    this -> row = row;
    this -> col = col;
    this -> mat = new int*[row];
    for(int i = 0; i < row; i ++) {
        this -> mat[i] = new int[col];
        for(int j = 0; j < col; j ++) {
            cin >> this -> mat[i][j];
        }
    }
}

void Matrix::add(const Matrix& other) {
    for(int i = 0; i < row; i ++) {
        for(int j = 0; j < col; j ++) {
            this -> mat[i][j] += other.mat[i][j];
        }
    }
}