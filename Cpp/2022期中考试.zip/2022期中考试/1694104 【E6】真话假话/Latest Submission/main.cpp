#include <iostream>
using namespace std;

int main(void) {
    int N;
    int state[N][2];
    cin >> N;
    for(int i = 0; i < N; i ++) {
        cin >> state[i][0] >> state[i][1];
    }
    for(int i = 0; i < N; i ++) {
        
    }
}