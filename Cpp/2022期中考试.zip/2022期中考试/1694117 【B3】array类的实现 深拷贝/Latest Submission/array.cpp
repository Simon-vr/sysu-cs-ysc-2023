#include <iostream>
#include "array.h"
using namespace std;

array::array(int size, int val) {
    this -> size = size;
    this -> data = new int[size];
    for(int i = 0; i < size; i ++) {
        this -> data[i] = val;
    }
}

array::array(const array &another) {
    this -> size = another.size;
    this -> data = new int[another.size];
    for(int i = 0; i < another.size; i ++) {
        this -> data[i] = another.data[i];
    }
}

array::~array() {
    if(this -> data != NULL) {
        delete[] this -> data;
    }
}

int& array::at(int pos) {
    return this -> data[pos];
}