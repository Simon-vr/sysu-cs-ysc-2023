#include "Player.hpp"
#include <iostream>
using namespace std;

int Player::numberOfObjects = 0;

Player::Player(int id) {
    this -> id = id;
    numberOfObjects ++;
}
Player::~Player() {
    numberOfObjects --;
}
int Player::getId() {
    return this -> id;
}
int Player::getNumberOfObjects() {
    return numberOfObjects;
} 