# 【D2】Player类

## 问题描述

根据头文件`Player.hpp`完善`Player`类

## 样例输入

```
111
```

## 样例输出

```
number of Player objects: 1
number of Player objects: 2
After creating worker1 and worker2
worker1 id: 111
worker2 id: 111
number of Player objects: 3
number of Player objects: 2
```

## 提示

静态成员变量

