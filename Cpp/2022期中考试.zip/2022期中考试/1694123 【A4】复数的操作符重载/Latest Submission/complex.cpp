#include "complex.h"
#include <iostream>
using namespace std;

COMPLEX::COMPLEX(double r, double i) {
    this -> real = r;
    this -> image = i;
}
COMPLEX::COMPLEX(const COMPLEX &other) {
    this -> real = other.real;
    this -> image = other.image;
}
void COMPLEX::print() {
    if(this -> real != 0) {
        cout << this -> real;
    }
    if(image > 0) {
        cout << "+" << this -> image;
    } else if(image < 0) {
        cout << this -> image;
    }
    cout << "i" << endl;
}
	
COMPLEX COMPLEX::operator+(const COMPLEX &other) {
    this -> real = this -> real + other.real;
    this -> image = this -> image + other.image;
    return *this;
}
COMPLEX COMPLEX::operator-(const COMPLEX &other) {
    this -> real = this -> real - other.real;
    this -> image = this -> image - other.image;
    return *this;
}
COMPLEX COMPLEX::operator-() {
    this -> real = 0 - this -> real;
    this -> image = 0 - this -> image;
    return *this;
}
COMPLEX COMPLEX::operator=(const COMPLEX &other) {
    this -> real = other.real;
    this -> image = other.image;
    return *this;
}
  
COMPLEX &COMPLEX::operator++() {
    this -> image ++;
    this -> real ++;
    return *this;
}
COMPLEX COMPLEX::operator++(int) {
    COMPLEX temp = *this;
    this -> image ++;
    this -> real ++;
    return temp;
}
COMPLEX &COMPLEX::operator--() {
    this -> image --;
    this -> real --;
    return *this;
}
COMPLEX COMPLEX::operator--(int) {
    COMPLEX temp = *this;
    this -> image --;
    this -> real --;
    return temp;
}