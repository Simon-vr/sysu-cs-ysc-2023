#include "Exchange.h"
#include <iostream>
using namespace std;

void Exchange::operator()(int& x, int& y) {
    int temp = x;
    x = y;
    y = temp;
}