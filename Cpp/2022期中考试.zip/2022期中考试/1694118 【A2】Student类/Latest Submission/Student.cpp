#include "Student.hpp"
#include <iostream>
using namespace std;

Date::Date() {
    this -> year = 0;
    this -> month = 0;
    this -> day = 0;
}
Date::Date(int year,int month,int day) : year(year), month(month), day(day) {}
int Date::getYear() {
    return this -> year;
}
void Date::setYear(int year) {
    this -> year = year;
}
int Date::getMonth() {
    return this -> month;
}
int Date::getDay() {
    return this -> day;
}
void Date::setMonth(int month) {
    this -> month = month;
}
void Date::setDay(int day) {
    this -> day = day;
}
void Date::Print() {
    cout << this -> year << " " << this -> month << " " << this -> day << endl;
}

int Student::numberOfObjects = 0;
Student::Student(int id, int year, int month, int day) {
    this -> id = id;
    this -> birthDate = new Date(year, month, day);
    numberOfObjects ++;
}
Student::~Student() {
    numberOfObjects --;
    delete this -> birthDate;
}
int Student::getId() {
    return this -> id;
}
Date* Student::getBirthDate() const {
    return this -> birthDate;
}
int Student::getNumberOfObjects() {
    return numberOfObjects;
}