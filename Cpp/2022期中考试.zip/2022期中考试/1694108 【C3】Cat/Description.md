# 【C3】Cat

## 问题描述

请给类Cat添加拷贝构造函数和赋值操作符函数.

测试输入包括一个整数n和n个名字。

## 样例输入

```
4
Thompson Davis Wright Perez
```

## 样例输出

```
Davis
Wright
Perez
```

