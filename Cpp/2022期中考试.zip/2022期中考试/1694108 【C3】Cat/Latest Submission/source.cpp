#include "Cat.h"

void Cat::_copy(const Cat & cat) {
    this -> size = cat.size;
    this -> name = cat.name;
    if(this -> family != NULL) {
        delete[] this -> family;
    }
    this -> family = new Cat*[size];
    for(int i = 0; i < cat.size; i ++) {
        this -> family[i] = cat.family[i];
    }
}

Cat::Cat(const Cat & cat) {
    this -> size = cat.size;
    this -> name = cat.name;
    this -> family = new Cat*[size];
    for(int i = 0; i < cat.size; i ++) {
        this -> family[i] = cat.family[i];
    }
}

Cat& Cat::operator=(const Cat & cat) {
    this -> size = cat.size;
    this -> name = cat.name;
    if(this -> family != NULL) {
        delete[] this -> family;
    }
    this -> family = new Cat*[size];
    for(int i = 0; i < cat.size; i ++) {
        this -> family[i] = cat.family[i];
    }
    return *this;
}