#include <iostream>
#include "Object.hpp"
using namespace std;

Object::Object(int a) {
    this -> size = a;
    this -> data = new int[a];
    for(int i = 0; i < a; i ++) {
        this -> data[i] = i+1;
    }
}

Object::Object(const Object& a) {
    this -> size = a.size;
    this -> data = new int[size];
    for(int i = 0; i < size; i ++) {
        this -> data[i] = a.data[i];
    }
}

Object::~Object() {
    delete[] this -> data;
}