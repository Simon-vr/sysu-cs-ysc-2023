#include "Dog.h"
#include <iostream>
using namespace std;

Dog::Dog(string name, int age) {
    this -> name = name;
    this -> age = age;
    this -> id = ++ count;
    this -> ifSetName = false;
}
int Dog::getId() const {
    return this -> id;
}
int Dog::getAge() const {
    return this -> age;
}
string Dog::getName() const {
    return this -> name;
}
bool Dog::setName(string name) {
    if(this -> ifSetName == true) {
        cout << "Set name failed!" << endl;
        return false;
    }
    this -> name = name;
    this -> ifSetName = true;
    return true;
}
void Dog::setAge(int age) {
    this -> age = age;
}
Dog::~Dog() {
    count --;
}