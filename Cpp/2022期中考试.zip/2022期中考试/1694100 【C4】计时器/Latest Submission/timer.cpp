#include <iostream>
#include "timer.hpp"
using namespace std;

void Timer::operator++(int a) {
    this -> min ++;
    if(this -> min == 60) {
        this -> hr ++;
        this -> min = 0;
    }
}

void Timer::operator--(int a) {
    if(this -> min == 0) {
        this -> hr --;
        this -> min = 60;
    }
    this -> min --;
}