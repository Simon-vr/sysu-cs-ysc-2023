#include "myspace.hpp"
#include <iostream>
using namespace std;

extern int sum;
extern int size;

void myspace::cout() {
    std::cout << sum << endl << ((double)sum/(double)size) << endl;
}
void myspace::read() {
    int num;
    while(std::cin >> num) {
        size ++;
        sum += num;
    }
}