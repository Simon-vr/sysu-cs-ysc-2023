#include "Worker.hpp"
#include <iostream>
using namespace std;

int Worker::numberOfObjects = 0;

Worker::Worker(int id) : id(id) {
    numberOfObjects ++;
}

Worker::~Worker() {
    numberOfObjects --;
}

int Worker::getId() {
    return this -> id;
}

int Worker::getNumberOfObjects() {
    return numberOfObjects;
}