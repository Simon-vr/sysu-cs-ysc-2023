#include <iostream>
#include "Points.h"
using namespace std;

TwoDPoint::TwoDPoint() : x(0), y(0) {}
TwoDPoint::TwoDPoint(double x, double y) : x(x), y(y) {}
double TwoDPoint::getX() const {
    return this -> x;
}
double TwoDPoint::getY() const {
    return this -> y;
}

TwoDPoint TwoDPoint::middlePoint(const TwoDPoint &point) {
    double mx = (this -> x + point.x) / 2;
    double my = (this -> y + point.y) / 2;
    TwoDPoint* temp = new TwoDPoint(mx, my);
    return *temp;
}
		
ThreeDPoint::ThreeDPoint() : TwoDPoint(), z(0) {}
ThreeDPoint::ThreeDPoint(double x, double y, double z) : TwoDPoint(x, y), z(z) {}
double ThreeDPoint::getZ() const {
    return this -> z;
}

ThreeDPoint ThreeDPoint::middlePoint(const ThreeDPoint &point) {
    double mx = (this -> getX() + point.getX()) / 2;
    double my = (this -> getY() + point.getY()) / 2;
    double mz = (this -> z + point.z) / 2;
    ThreeDPoint* temp = new ThreeDPoint(mx, my, mz);
    return *temp;
}