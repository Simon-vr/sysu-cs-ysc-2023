#include "Account.hpp"
#include <iostream>
using namespace std;

Account::Account() {
    this -> id = 0;
    this -> balance = 0;
    this -> annualInterestRate = 0;
}
Account::Account(int id_ , double balance_ , double annualInterestRate_ ) {
    this -> id = id_;
    this -> balance = balance_;
    this -> annualInterestRate = annualInterestRate_;
}
int Account::getId() const {
    return this -> id;
}
double Account::getBalance()const {
    return this -> balance;
}
double Account::getAnnualInterestRate()const {
    return this -> annualInterestRate;
}

void Account::setId(int id_) {
    this -> id = id_;
}
void Account::setBalance(double balance_) {
    this -> balance = balance_;
}
void Account::setAnnualInterestRate(double rate_) {
    this -> annualInterestRate = rate_;
}

void Account::withDraw(double amount) {
    if(this -> balance <= amount) {
        amount = this -> balance;
        this -> balance = 0;
    } else {
        this -> balance -= amount;
    }
    cout << amount << "$ has been withdrawn! Balance of account " << this -> id << " is " << balance << endl;
}
void Account::deposit(double amount) {
    this -> balance += amount;
    cout << amount << "$ has been deposited! Balance of account " << this -> id << " is " << balance << endl;
}
void Account::transfer(Account &account,double amount) {
    if(this -> balance < amount) {
        cout << "Transferring failed: balance of account " << this -> id << " is not enough!" << endl;
        return;
    }
    this -> balance -= amount;
    account.balance += amount;
    cout << amount << "$ has been transferred! Balance of account " << this -> id <<  " is " << this -> balance << endl;
}