#include "StudentList.h"

StudentList::StudentList(unsigned int _capacity) {
    this -> size = 0;
    this -> capacity = _capacity;
    this -> student = new Student[_capacity];
}

void StudentList::addStudent(string &name, int age) {
    if(this -> size < capacity) {
        this -> student[size].name = name;
        this -> student[size].age = age;
        size ++;
    }    
}

StudentList::~StudentList() {
    delete[] student;
}