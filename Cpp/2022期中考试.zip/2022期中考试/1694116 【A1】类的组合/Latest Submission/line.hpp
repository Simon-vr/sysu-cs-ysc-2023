#include <iostream>
#include <cmath>
#include "point.hpp"
using namespace std;

class Line {
    private:
        Point *p1, *p2;
    public:
        Line(Point& p1, Point& p2) {
            this -> p1 = new Point(p1);
            this -> p2 = new Point(p2);
        }
        Line(Line& line) {
            this -> p1 = new Point(*line.p1);
            this -> p2 = new Point(*line.p2);
        }

        double getLen() {
            double dx = this -> p1 -> getX() - this -> p2 -> getX();
            double dy = this -> p1 -> getY() - this -> p2 -> getY();
            return pow((dx * dx + dy * dy), 0.5);
        }
};