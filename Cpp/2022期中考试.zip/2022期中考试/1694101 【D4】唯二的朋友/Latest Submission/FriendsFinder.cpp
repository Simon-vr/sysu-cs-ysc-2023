#include <iostream>
#include "FriendsFinder.hpp"
using namespace std;

void FriendsFinder::operator()() {
    string output[100];
    string result[100];
    int total = 0;
    for(int i = 0; i < 10; i ++) {
        for(int j = 0; j < 10; j ++) {
            output[i*10 + j] = friends[i][j];
        }
    }
    for(int i = 0;i < 100; i ++) {
		int mink = i;
		for(int j = i + 1; j < 100; j ++) {
			if(output[mink] > output[j]) {
                mink = j;
            }
		}
		if(mink != i) {
			string t = output[i];
            output[i] = output[mink];
            output[mink] = t;
		}
	}
    for(int i = 0; i < 100; i ++) {
        int count = 1;
        while(output[i] == output[i + 1]) {
            i ++;
            count ++;
        }
        if(count == 2) {
            result[total ++] = output[i];
        }
    }
    for(int i = 0; i < total; i ++) {
        cout << result[i] << " ";
    }
}