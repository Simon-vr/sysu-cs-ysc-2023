#include "RGene.hpp"
#include <iostream>
using namespace std;

RGene::RGene(const baseR* seq_, int num_) : num(num_) {
    this -> seq = new baseR[num_];
    for(int i = 0; i < num_; i ++) {
        this -> seq[i] = seq_[i];
    }
}

RGene::RGene(const RGene& other) {
    this -> num = other.num;
    this -> seq = new baseR[num];
    for(int i = 0; i < num; i ++) {
        this -> seq[i] = other.seq[i];
    }
}

RGene RGene::trans() const {
    for(int i = 0; i < this -> num; i ++) {
        switch(this -> seq[i]) {
            case A:   seq[i]=U;   break;
            case G:   seq[i]=C;   break;
            case C:   seq[i]=G;   break;
            case U:   seq[i]=A;   break;
        }
    }
    return *this;
}

void RGene::printSeq() const {
    if(this -> num != 0) {
        for(int i = 0; i < this -> num; i ++) {
            switch(this -> seq[i]) {
                case A:   cout << 'A';   break;
                case G:   cout << 'G';   break;
                case C:   cout << 'C';   break;
                case U:   cout << 'U';   break;
            }
        }
    } else {
        cout << "empty data";
    }
    cout << endl;
}

RGene::~RGene() {
    delete[] this -> seq;
}