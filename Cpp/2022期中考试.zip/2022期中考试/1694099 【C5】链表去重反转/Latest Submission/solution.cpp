#include <iostream>
#include <set>
#include "ListNode.h"
using namespace std;

ListNode* deleteDuplicates(ListNode *head) {
    set<int> s;
    ListNode* cur = head;
    while(cur && cur -> next) {
        s.insert(cur -> val);
        if(s.count(cur -> next -> val)) {
            cur -> next = cur -> next -> next;
        } else {
            cur = cur -> next;
        }
    }
    return head;
}

extern ListNode* reverseList(ListNode* head) {
    ListNode* pre = NULL;
    ListNode* current = deleteDuplicates(head);
    ListNode* temp = NULL;
    while (current != NULL) {
        temp = current -> next;
        current -> next = pre;
        pre = current;
        current = temp;
    }
    return pre;
}