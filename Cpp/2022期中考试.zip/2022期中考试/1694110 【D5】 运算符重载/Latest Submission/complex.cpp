#include <iostream>
#include "complex.h"
using namespace std;

COMPLEX::COMPLEX(double r, double i) : real(r), image(i) {}
COMPLEX::COMPLEX(const COMPLEX &other) {
    this -> real = other.real;
    this -> image = other.image;
}
void COMPLEX::print() {
    cout << this -> real;
    if(this -> image < 0) {
        cout << this -> image << "i" << endl;
    } else if(this -> image > 0) {
        cout << "+" << this -> image << "i" << endl;
    } else {
        cout << endl;
    }
}
	
COMPLEX COMPLEX::operator+(const COMPLEX &other) {
    this -> real = this -> real + other.real;
    this -> image = this -> image + other.image;
    return *this;
}
COMPLEX COMPLEX::operator-(const COMPLEX &other) {
    this -> real = this -> real - other.real;
    this -> image = this -> image - other.image;
    return *this;
}
COMPLEX COMPLEX::operator-() {
    this -> real = 0 - this -> real;
    this -> image = 0 - this -> image;
    return *this;
}
COMPLEX COMPLEX::operator=(const COMPLEX &other) {
    this -> real = other.real;
    this -> image = other.image;
    return *this;
}
  
COMPLEX& COMPLEX::operator++() {
    this -> real ++;
    return *this;
}
COMPLEX COMPLEX::operator++(int) {
    COMPLEX *temp = new COMPLEX(this -> real, this -> image);
    this -> real ++;
    return *temp;
}
COMPLEX& COMPLEX::operator--() {
    this -> real --;
    return *this;
}
COMPLEX COMPLEX::operator--(int) {
    COMPLEX *temp = new COMPLEX(this -> real, this -> image);
    this -> real --;
    return *temp;
}