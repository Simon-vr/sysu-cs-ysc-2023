#include "line.h"
#include <iostream>
#include <cmath>
using namespace std;

Line::Line(Point xp1, Point xp2, char* name) : p1(xp1), p2(xp2) {
    this -> name = name;
    this -> len = sqrt(pow((xp1.getX()-xp2.getX()), 2) + pow((xp1.getY()-xp2.getY()), 2));
}
double Line::getLen() const {
    return this -> len;
}
char* Line::getName() const {
    return this -> name;
}
Line::~Line() {}