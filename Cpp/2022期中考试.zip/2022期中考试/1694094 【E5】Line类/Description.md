# 【E5】Line类

## 问题描述

题目已给出`Point`类的定义和`Line`类的声明，要求完善Line类的函数。其中的成员`name`表示线段的名字，需要使用new和delete动态创建和释放。一条线段的长度由两个点的坐标计算而来。

## 样例输入

```
0 0 3 4
aka
```

## 样例输出

```
The name of the line is: aka
The length of the line is: 5
```

## Hint

计算开方可以使用函数sqrt（需要include<math.h>），例如

```
sqrt(8);
```
