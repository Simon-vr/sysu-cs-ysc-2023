#include <iostream>
#include "Date.h"
using namespace std;

DATE::DATE() : year(2000), month(1), day(1) {
    cout << "A defaut DATE class has been created!" << endl;
}

DATE::DATE(int newYear, int newMonth, int newDay) : year(newYear), month(newMonth), day(newDay) {
    cout << "A specified DATE class has been created!" << endl;
}

DATE::~DATE() {
    cout << "The DATE CLASS will be destroyed." << endl;
}

int DATE::getMonth() const {
    return this -> month;
}
int DATE::getDay() const {
    return this -> day;
}
int DATE::getYear() const {
    return this -> year;
}

bool DATE::isLeapYear() const {
    if((this -> year % 4 == 0) && (this -> year % 100 != 0)) {
        return true;
    } else if(this -> year % 400 == 0) {
        return true;
    }
    return false;
}

int DATE::daysInMonth() const {
    switch(this -> month) {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:    return 31;
        case 4:
        case 6:
        case 9:
        case 11:    return 30;
        case 2: {
            if(this -> isLeapYear()) {
                return 29;
            }
            return 28;
        }
        default:    return 0;
    }
}